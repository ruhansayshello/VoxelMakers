/**
 * VoxlCraft — Standalone Minecraft Clone Showcase powered 100% by the extracted Voxl Engine (`src/voxl`).
 * ZERO imports from VoxelMakers (`src/game`).
 */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Sliders,
  X,
  Flame,
  RefreshCw,
  RotateCcw,
  ArrowLeft,
  Cpu,
  Layers,
  Sparkles,
  Sun,
  Moon,
  Compass,
  Box,
  Download,
} from 'lucide-react';
import * as Voxl from '../../src';
import {
  MC_BLOCK,
  MC_BLOCK_BY_ID,
  MC_HOTBAR_BLOCKS,
  MinecraftWorldController,
  type MinecraftPlayerState,
} from './minecraftWorld';
import {
  createProceduralBlockTexture,
  createVoxlBloomShader,
  createVoxlRetroPixelShader,
  createVoxlVignetteShader,
} from './minecraftTextures';

export type ShaderMode = 'potato' | 'lambert' | 'basic';
export type FogMode = 'linear' | 'exp2' | 'off';

export interface VoxlFeatureToggles {
  chunkBatching: boolean;
  gpuCulling: boolean;
  shaderMode: ShaderMode;
  bakedAO: boolean;
  gpuLod: boolean;
  proceduralTexture: boolean;
  fogMode: FogMode;
  dayNightCycle: boolean;
  timeOfDay: number; // 0..1 (0.28 = bright morning/noon, 0.52 = sunset, 0.8 = night)
  pointLights: boolean;
  postProcessing: boolean;
  bloomPass: boolean;
  vignettePass: boolean;
  retroPixelPass: boolean;
  soaDebris: boolean;
  instancedFoliage: boolean;
  wireframeCursor: boolean;
  flyMode: boolean;
  perfHud: boolean;
}

const DEFAULT_TOGGLES: VoxlFeatureToggles = {
  chunkBatching: true,
  gpuCulling: true,
  shaderMode: 'potato',
  bakedAO: true,
  gpuLod: true,
  proceduralTexture: true,
  fogMode: 'linear',
  dayNightCycle: false,
  timeOfDay: 0.24,
  pointLights: true,
  postProcessing: false,
  bloomPass: true,
  vignettePass: true,
  retroPixelPass: false,
  soaDebris: true,
  instancedFoliage: true,
  wireframeCursor: true,
  flyMode: false,
  perfHud: true,
};

interface HudStats {
  fps: number;
  frameMs: number;
  drawCalls: number;
  triangles: number;
  visibleChunks: number;
  totalChunks: number;
  activeDebris: number;
  gpuCullerActive: boolean;
  targetBlockName: string | null;
  playerPos: string;
}

interface MinecraftDemoProps {
  onExitToVoxelMakers?: () => void;
}

export const MinecraftDemo: React.FC<MinecraftDemoProps> = ({ onExitToVoxelMakers }) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [toggles, setToggles] = useState<VoxlFeatureToggles>(DEFAULT_TOGGLES);
  const togglesRef = useRef<VoxlFeatureToggles>(DEFAULT_TOGGLES);
  const [selectedSlot, setSelectedSlot] = useState<number>(0);
  const selectedSlotRef = useRef<number>(0);
  const [panelOpen, setPanelOpen] = useState<boolean>(true);
  const [seed, setSeed] = useState<number>(1337);
  const [isPointerLocked, setIsPointerLocked] = useState<boolean>(false);
  const [stats, setStats] = useState<HudStats>({
    fps: 60,
    frameMs: 16.6,
    drawCalls: 1,
    triangles: 0,
    visibleChunks: 0,
    totalChunks: 49,
    activeDebris: 0,
    gpuCullerActive: false,
    targetBlockName: null,
    playerPos: '0, 14, 4',
  });

  // Action hooks into the WebGL loop
  const actionsRef = useRef<{
    detonateTnt: () => void;
    resetPlayer: () => void;
    rebuildAllChunks: () => void;
  }>({
    detonateTnt: () => {},
    resetPlayer: () => {},
    rebuildAllChunks: () => {},
  });

  useEffect(() => {
    togglesRef.current = toggles;
  }, [toggles]);

  useEffect(() => {
    selectedSlotRef.current = selectedSlot;
  }, [selectedSlot]);

  // Trigger chunk remesh whenever Baked AO changes
  const prevBakedAoRef = useRef<boolean>(toggles.bakedAO);
  useEffect(() => {
    if (prevBakedAoRef.current !== toggles.bakedAO) {
      prevBakedAoRef.current = toggles.bakedAO;
      actionsRef.current.rebuildAllChunks();
    }
  }, [toggles.bakedAO]);

  const updateToggle = useCallback(
    <K extends keyof VoxlFeatureToggles>(key: K, value: VoxlFeatureToggles[K]) => {
      setToggles((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Initialize standalone Voxl WebGL2 Renderer
    const renderer = new Voxl.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    const gl = renderer.getContext();
    const rendererStr = String(gl?.getParameter(gl.RENDERER) ?? '');
    const isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(rendererStr);

    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.outputColorSpace = Voxl.LinearSRGBColorSpace;
    renderer.toneMapping = Voxl.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.85;

    const canvas = renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    container.innerHTML = '';
    container.appendChild(canvas);

    // 2. Scene & Camera
    const scene = new Voxl.Scene();
    const skyColor = new Voxl.Color(0x7cc4f5);
    scene.background = skyColor;

    const camera = new Voxl.PerspectiveCamera(
      72,
      (container.clientWidth || window.innerWidth) / Math.max(1, container.clientHeight || window.innerHeight),
      0.1,
      260,
    );

    // 3. Lighting System (Ambient + Hemisphere + Sun Directional + 3 Torch PointLights)
    const ambientLight = new Voxl.AmbientLight(0xdbeafe, 0.35);
    scene.add(ambientLight);

    const hemiLight = new Voxl.HemisphereLight(0x9bd4ff, 0x4b5e3c, 0.65);
    scene.add(hemiLight);

    const sunLight = new Voxl.DirectionalLight(0xfff5dc, 1.35);
    sunLight.position.set(42, 68, 28);
    scene.add(sunLight);

    const sunOrbGeo = new Voxl.BoxGeometry(6, 6, 6);
    const sunOrbMat = new Voxl.MeshBasicMaterial({ color: 0xffe484, fog: false });
    const sunOrbMesh = new Voxl.Mesh(sunOrbGeo, sunOrbMat);
    scene.add(sunOrbMesh);

    // 4. Procedural CanvasTexture & Opaque/Transparent Material Set
    const blockTex = createProceduralBlockTexture();

    // VoxelPotatoShader with white palette albedos so rich per-vertex block colors + baked AO
    // combine cleanly with per-material hardness, Fresnel rim, 3-band cel shading, and GPU LOD!
    const potatoPalette = Voxl.createDefaultVoxelMaterialPalette().map((entry) => ({
      ...entry,
      color: new Voxl.Color(0xffffff),
      aoContribution: 1.0,
    }));

    const potatoMat = Voxl.createVoxelPotatoMaterial({
      palette: potatoPalette,
      lightDir: new Voxl.Vector3(0.45, 0.82, 0.35),
      sunTint: 0xfff7e6,
      shadowTint: 0x6b87b0,
      rimColor: 0xd8f0ff,
      rimIntensity: 0.38,
      fogEnabled: true,
      fogColor: 0x7cc4f5,
      fogNear: 24,
      fogFar: 92,
      enableGpuLod: true,
      lodDistances: new Voxl.Vector2(26, 92),
    });

    const lambertMat = new Voxl.MeshLambertMaterial({
      vertexColors: true,
      map: blockTex,
    });

    const basicMat = new Voxl.MeshBasicMaterial({
      vertexColors: true,
      map: blockTex,
    });

    const transparentMat = new Voxl.MeshLambertMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.66,
      depthWrite: false,
      side: Voxl.DoubleSide,
    });

    // 5. Voxel World Controller (backed by Voxl.VoxelWorld SoA)
    const world = new MinecraftWorldController(3, seed);

    // Add Torch PointLights at landmark locations
    const torchLights: Voxl.PointLight[] = [];
    for (const loc of world.torches) {
      const pl = new Voxl.PointLight(0xffb44c, 2.8, 22, 1.5);
      pl.position.set(loc.x + 0.5, loc.y, loc.z + 0.5);
      scene.add(pl);
      torchLights.push(pl);
    }

    // 6. ChunkBatchRenderer (1-draw-call merged geometry) & GPUChunkCuller (WebGL2 Transform Feedback)
    const chunkBatcher = new Voxl.ChunkBatchRenderer({
      maxVertexCount: 320000,
      maxIndexCount: 520000,
      material: potatoMat,
      enableGpuLod: true,
    });
    scene.add(chunkBatcher.mesh);

    const gpuCuller = new Voxl.GPUChunkCuller(gl, 256);

    const unbatchedGroup = new Voxl.Group();
    scene.add(unbatchedGroup);

    const transparentGroup = new Voxl.Group();
    scene.add(transparentGroup);

    const chunkList = Array.from(world.chunks.values());
    const chunkSpheres = chunkList.map((c) => c.worldSphere);

    const buildChunkMeshes = (rec: (typeof chunkList)[number]) => {
      if (rec.opaqueMesh) {
        unbatchedGroup.remove(rec.opaqueMesh);
        rec.opaqueMesh = null;
      }
      if (rec.transMesh) {
        transparentGroup.remove(rec.transMesh);
        rec.transMesh = null;
      }

      world.rebuildChunkGeometries(rec, {
        bakeAO: togglesRef.current.bakedAO,
        encodeColorInVertices: true,
        buildLod1: true,
      });

      if (rec.opaqueGeo && rec.opaqueGeo.attributes.position && rec.opaqueGeo.attributes.position.count > 0) {
        rec.opaqueMesh = new Voxl.Mesh(rec.opaqueGeo, potatoMat);
        rec.opaqueMesh.position.set(rec.originX, 0, rec.originZ);
        rec.opaqueMesh.frustumCulled = false; // Handled explicitly by GPUChunkCuller / Batcher
        unbatchedGroup.add(rec.opaqueMesh);

        rec.batchEntry = {
          id: `${rec.cx},${rec.cz}:0`,
          geometry: rec.opaqueGeo,
          position: { x: rec.originX, y: 0, z: rec.originZ },
          boundingSphere: rec.worldSphere,
          lodLevel: 0,
        };
      } else {
        rec.batchEntry = null;
      }

      if (rec.lod1Geo && rec.lod1Geo.attributes.position && rec.lod1Geo.attributes.position.count > 0) {
        rec.lod1BatchEntry = {
          id: `${rec.cx},${rec.cz}:1`,
          geometry: rec.lod1Geo,
          position: { x: rec.originX, y: 0, z: rec.originZ },
          boundingSphere: rec.worldSphere,
          lodLevel: 1,
        };
      } else {
        rec.lod1BatchEntry = null;
      }

      if (rec.transGeo && rec.transGeo.attributes.position && rec.transGeo.attributes.position.count > 0) {
        rec.transMesh = new Voxl.Mesh(rec.transGeo, transparentMat);
        rec.transMesh.position.set(rec.originX, 0, rec.originZ);
        rec.transMesh.frustumCulled = false;
        transparentGroup.add(rec.transMesh);
      }

      chunkBatcher.markDirty();
    };

    for (let i = 0; i < chunkList.length; i++) {
      buildChunkMeshes(chunkList[i]);
    }

    // 7. InstancedMesh #1: VoxelWorld SoA Physics Debris (1 draw call for up to 450 cubes)
    const debrisCapacity = 450;
    const debrisGeo = new Voxl.BoxGeometry(1, 1, 1);
    const debrisMat = new Voxl.MeshLambertMaterial({ color: 0xffffff });
    const debrisInstanced = new Voxl.InstancedMesh(debrisGeo, debrisMat, debrisCapacity);
    debrisInstanced.count = 0;
    debrisInstanced.frustumCulled = false;
    scene.add(debrisInstanced);

    // 8. InstancedMesh #2: Procedural Grass & Wildflowers (1 draw call for up to 900 blades)
    const foliageCount = world.foliage.length;
    const foliageGeo = new Voxl.BoxGeometry(0.16, 1.0, 0.16);
    const foliageMat = new Voxl.MeshLambertMaterial({ color: 0xffffff });
    const foliageInstanced = new Voxl.InstancedMesh(foliageGeo, foliageMat, Math.max(1, foliageCount));
    foliageInstanced.frustumCulled = false;
    const tempMat = new Voxl.Matrix4();
    const tempPos = new Voxl.Vector3();
    const tempQuat = new Voxl.Quaternion();
    const tempEuler = new Voxl.Euler();
    const tempScale = new Voxl.Vector3();
    const tempColor = new Voxl.Color();

    for (let i = 0; i < foliageCount; i++) {
      const f = world.foliage[i];
      tempPos.set(f.x, f.y + f.scaleY * 0.5, f.z);
      tempEuler.set(0, (i * 1.618) % (Math.PI * 2), 0);
      tempQuat.setFromEuler(tempEuler);
      tempScale.set(1, f.scaleY, 1);
      tempMat.compose(tempPos, tempQuat, tempScale);
      foliageInstanced.setMatrixAt(i, tempMat);
      tempColor.setHex(f.color);
      foliageInstanced.setColorAt(i, tempColor);
    }
    foliageInstanced.count = foliageCount;
    foliageInstanced.instanceMatrix.needsUpdate = true;
    if (foliageInstanced.instanceColor) foliageInstanced.instanceColor.needsUpdate = true;
    scene.add(foliageInstanced);

    // 9. Wireframe Block Cursor (EdgesGeometry + LineSegments)
    const cursorBoxGeo = new Voxl.BoxGeometry(1.02, 1.02, 1.02);
    const cursorEdgesGeo = new Voxl.EdgesGeometry(cursorBoxGeo);
    const cursorMat = new Voxl.LineBasicMaterial({ color: 0x0f172a });
    const cursorWireframe = new Voxl.LineSegments(cursorEdgesGeo, cursorMat);
    cursorWireframe.visible = false;
    scene.add(cursorWireframe);

    // 10. EffectComposer Post-Processing Pipeline (RenderPass -> Bloom -> Vignette -> RetroPixel -> OutputPass)
    const composer = new Voxl.EffectComposer(renderer);
    const renderPass = new Voxl.RenderPass(scene, camera);
    const bloomPass = new Voxl.ShaderPass(createVoxlBloomShader());
    const vignettePass = new Voxl.ShaderPass(createVoxlVignetteShader());
    const retroPass = new Voxl.ShaderPass(createVoxlRetroPixelShader());
    const outputPass = new Voxl.OutputPass();

    composer.addPass(renderPass);
    composer.addPass(bloomPass);
    composer.addPass(vignettePass);
    composer.addPass(retroPass);
    composer.addPass(outputPass);

    const updatePassResolutions = (w: number, h: number) => {
      const pr = renderer.getPixelRatio();
      const pw = Math.max(1, Math.floor(w * pr));
      const ph = Math.max(1, Math.floor(h * pr));
      composer.setSize(w, h);
      (bloomPass.uniforms.uResolution.value as Voxl.Vector2).set(pw, ph);
      (retroPass.uniforms.uResolution.value as Voxl.Vector2).set(pw, ph);
    };
    updatePassResolutions(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight,
    );

    // 11. Player Controller State (looking straight at the watchtower, TNT cluster & lake!)
    const player: MinecraftPlayerState = {
      position: world.spawnPoint.clone(),
      velocity: new Voxl.Vector3(0, 0, 0),
      yaw: 0.14,
      pitch: -0.1,
      onGround: false,
      inWater: false,
      flyMode: togglesRef.current.flyMode,
    };

    const keys: Record<string, boolean> = {};
    const lookDir = new Voxl.Vector3();
    let currentHit: Voxl.VoxelDDARaycastHit | null = null;

    const getLookDirection = (out: Voxl.Vector3): Voxl.Vector3 => {
      const cosP = Math.cos(player.pitch);
      return out.set(-Math.sin(player.yaw) * cosP, Math.sin(player.pitch), -Math.cos(player.yaw) * cosP).normalize();
    };

    const triggerTntExplosion = () => {
      // Search for a TNT block within 24m first; otherwise blast right in front of the player!
      const px = Math.floor(player.position.x);
      const py = Math.floor(player.position.y);
      const pz = Math.floor(player.position.z);
      let found: { x: number; y: number; z: number } | null = null;
      let bestDistSq = Infinity;

      for (let dz = -18; dz <= 18; dz++) {
        for (let dx = -18; dx <= 18; dx++) {
          for (let dy = -8; dy <= 8; dy++) {
            const bx = px + dx;
            const by = py + dy;
            const bz = pz + dz;
            if (world.getBlock(bx, by, bz) === MC_BLOCK.TNT) {
              const dSq = dx * dx + dy * dy + dz * dz;
              if (dSq < bestDistSq) {
                bestDistSq = dSq;
                found = { x: bx, y: by, z: bz };
              }
            }
          }
        }
      }

      if (found) {
        world.detonateExplosion(found.x + 0.5, found.y + 0.5, found.z + 0.5, 3.8, togglesRef.current.soaDebris);
      } else {
        getLookDirection(lookDir);
        const hit = world.raycastBlock(player.position, lookDir, 18);
        const cx = hit ? hit.wx + 0.5 : player.position.x + lookDir.x * 7;
        const cy = hit ? hit.wy + 0.5 : Math.max(4, player.position.y + lookDir.y * 5);
        const cz = hit ? hit.wz + 0.5 : player.position.z + lookDir.z * 7;
        world.detonateExplosion(cx, cy, cz, 3.6, togglesRef.current.soaDebris);
      }
    };

    actionsRef.current = {
      detonateTnt: triggerTntExplosion,
      resetPlayer: () => {
        player.position.copy(world.spawnPoint);
        player.velocity.set(0, 0, 0);
        player.yaw = 0.14;
        player.pitch = -0.1;
      },
      rebuildAllChunks: () => {
        for (let i = 0; i < chunkList.length; i++) {
          buildChunkMeshes(chunkList[i]);
        }
      },
    };

    // 12. Input Handling (WASD + Space + Shift + Drag Look + Pointer Lock + LMB Break + RMB Place)
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      keys[e.code] = true;
      if (e.code === 'Space') e.preventDefault();

      if (e.code.startsWith('Digit')) {
        const idx = parseInt(e.code.replace('Digit', ''), 10) - 1;
        if (idx >= 0 && idx < MC_HOTBAR_BLOCKS.length) {
          setSelectedSlot(idx);
        }
      } else if (e.code === 'KeyF') {
        triggerTntExplosion();
      } else if (e.code === 'Tab') {
        e.preventDefault();
        setPanelOpen((v) => !v);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    let isDragging = false;
    let dragDistance = 0;
    let lastMouseX = 0;
    let lastMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        isDragging = true;
        dragDistance = 0;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
        if (document.pointerLockElement === canvas && currentHit) {
          world.breakBlock(currentHit.wx, currentHit.wy, currentHit.wz, togglesRef.current.soaDebris);
        }
      } else if (e.button === 2) {
        if (currentHit) {
          const px = currentHit.wx + currentHit.normalX;
          const py = currentHit.wy + currentHit.normalY;
          const pz = currentHit.wz + currentHit.normalZ;
          const selectedBlock = MC_HOTBAR_BLOCKS[selectedSlotRef.current]?.id ?? MC_BLOCK.STONE;
          // Prevent placing directly inside player's head/body
          const dx = Math.abs(px + 0.5 - player.position.x);
          const dz = Math.abs(pz + 0.5 - player.position.z);
          const dy = player.position.y - (py + 0.5);
          if (!(dx < 0.75 && dz < 0.75 && dy > -0.6 && dy < 1.9)) {
            world.setBlock(px, py, pz, selectedBlock);
          }
        }
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0 && isDragging) {
        isDragging = false;
        // Short click without pointer lock: break targeted block
        if (document.pointerLockElement !== canvas && dragDistance < 6 && currentHit) {
          world.breakBlock(currentHit.wx, currentHit.wy, currentHit.wz, togglesRef.current.soaDebris);
        }
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      const sensitivity = 0.0028;
      if (document.pointerLockElement === canvas) {
        player.yaw -= e.movementX * sensitivity;
        player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch - e.movementY * sensitivity));
      } else if (isDragging) {
        const dx = e.clientX - lastMouseX;
        const dy = e.clientY - lastMouseY;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
        dragDistance += Math.abs(dx) + Math.abs(dy);
        player.yaw -= dx * sensitivity * 1.25;
        player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch - dy * sensitivity * 1.25));
      }
    };

    const onDblClick = () => {
      if (document.pointerLockElement !== canvas && typeof canvas.requestPointerLock === 'function') {
        canvas.requestPointerLock();
      }
    };

    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    const onPointerLockChange = () => {
      setIsPointerLocked(document.pointerLockElement === canvas);
    };

    const onResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      updatePassResolutions(w, h);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', onResize);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mousedown', onMouseDown);
    canvas.addEventListener('dblclick', onDblClick);
    canvas.addEventListener('contextmenu', onContextMenu);
    document.addEventListener('pointerlockchange', onPointerLockChange);

    // 13. Profiler & Animation Loop
    const profiler = new Voxl.PerfProfiler();
    const fogColorObj = new Voxl.Color(0x7cc4f5);
    const linearFog = new Voxl.Fog(0x7cc4f5, 22, 86);
    const exp2Fog = new Voxl.FogExp2(0x7cc4f5, 0.019);
    const activeBatchChunks: Voxl.BatchableChunk[] = [];
    const camEuler = new Voxl.Euler(0, 0, 0, 'YXZ');

    let simTimeOfDay = togglesRef.current.timeOfDay;
    let lastTime = performance.now();
    let elapsed = 0;
    let hudTimer = 0;
    let lastDrawCalls = 0;
    let lastTriangles = 0;
    let lastVisibleChunks = chunkList.length;
    let prevTexEnabled = togglesRef.current.proceduralTexture;
    let prevGpuLod = togglesRef.current.gpuLod;
    let prevShaderMode = togglesRef.current.shaderMode;
    let rafId = 0;

    const animate = (now: number) => {
      rafId = requestAnimationFrame(animate);
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;
      elapsed += dt;

      const cfg = togglesRef.current;
      const frameDeltaMs = Math.max(0.1, dt * 1000);
      profiler.beginFrame();

      // A. Rebuild any dirty chunks (from block place / break / TNT explosion)
      let dirtyCount = 0;
      for (let i = 0; i < chunkList.length; i++) {
        const rec = chunkList[i];
        if (world.voxlWorld.chunkDirty[rec.slot] !== 0) {
          buildChunkMeshes(rec);
          dirtyCount++;
        }
      }

      // B. Player Movement & Camera
      player.flyMode = cfg.flyMode;
      world.stepPlayer(player, keys, dt);

      camera.position.copy(player.position);
      camEuler.set(player.pitch, player.yaw, 0, 'YXZ');
      camera.quaternion.setFromEuler(camEuler);
      camera.updateMatrixWorld(true);

      // C. Raycast Block Target & Wireframe Cursor
      getLookDirection(lookDir);
      currentHit = world.raycastBlock(player.position, lookDir, 7.5);
      if (cfg.wireframeCursor && currentHit) {
        cursorWireframe.visible = true;
        cursorWireframe.position.set(currentHit.wx + 0.5, currentHit.wy + 0.5, currentHit.wz + 0.5);
      } else {
        cursorWireframe.visible = false;
      }

      // D. Dynamic Day / Night Cycle & Lighting
      if (cfg.dayNightCycle) {
        simTimeOfDay = (simTimeOfDay + dt * 0.035) % 1;
      } else {
        simTimeOfDay = cfg.timeOfDay;
      }
      const sunAngle = simTimeOfDay * Math.PI * 2;
      const sunY = Math.sin(sunAngle);
      const sunX = Math.cos(sunAngle);
      const sunZ = 0.35;
      const dayFactor = Math.max(0, Math.min(1, sunY * 1.7 + 0.25));
      const sunsetFactor = Math.max(0, 1 - Math.abs(sunY) * 3.8);

      sunLight.position.set(sunX * 80, sunY * 80, sunZ * 80);
      sunLight.intensity = 0.22 + dayFactor * 1.25;
      sunOrbMesh.position.set(
        player.position.x + sunX * 135,
        player.position.y + sunY * 135,
        player.position.z + sunZ * 135,
      );
      sunOrbMesh.visible = sunY > -0.15;

      // Blend sky color smoothly from deep night -> warm sunset -> crisp sky blue
      const rSky = 0.06 + dayFactor * 0.42 + sunsetFactor * 0.44;
      const gSky = 0.09 + dayFactor * 0.67 + sunsetFactor * 0.22;
      const bSky = 0.18 + dayFactor * 0.78 - sunsetFactor * 0.06;
      skyColor.setRGB(Math.min(1, rSky), Math.min(1, gSky), Math.min(1, bSky));
      fogColorObj.copy(skyColor);

      ambientLight.intensity = 0.14 + dayFactor * 0.3;
      hemiLight.intensity = 0.16 + dayFactor * 0.55;

      // Update Torch PointLights
      for (let i = 0; i < torchLights.length; i++) {
        const flicker = 0.92 + Math.sin(elapsed * 9 + i * 2.1) * 0.08;
        torchLights[i].intensity = cfg.pointLights ? (2.2 + (1 - dayFactor) * 2.4) * flicker : 0;
      }

      // E. Atmospheric Fog (Fog / FogExp2 / Off)
      if (cfg.fogMode === 'linear') {
        linearFog.color.copy(fogColorObj);
        scene.fog = linearFog;
      } else if (cfg.fogMode === 'exp2') {
        exp2Fog.color.copy(fogColorObj);
        scene.fog = exp2Fog;
      } else {
        scene.fog = null;
      }

      // F. Sync Materials & Procedural CanvasTexture
      if (prevTexEnabled !== cfg.proceduralTexture) {
        prevTexEnabled = cfg.proceduralTexture;
        lambertMat.map = cfg.proceduralTexture ? blockTex : null;
        lambertMat.needsUpdate = true;
        basicMat.map = cfg.proceduralTexture ? blockTex : null;
        basicMat.needsUpdate = true;
      }

      const activeOpaqueMat: Voxl.Material =
        cfg.shaderMode === 'potato'
          ? potatoMat
          : cfg.shaderMode === 'lambert'
            ? lambertMat
            : basicMat;

      // Sync VoxelPotatoShader uniforms
      (potatoMat.uniforms.uLightDir.value as Voxl.Vector3)
        .set(sunX, Math.max(0.18, sunY), sunZ)
        .normalize();
      (potatoMat.uniforms.uSunTint.value as Voxl.Color).setRGB(
        0.55 + dayFactor * 0.45 + sunsetFactor * 0.22,
        0.52 + dayFactor * 0.45 + sunsetFactor * 0.06,
        0.65 + dayFactor * 0.25 - sunsetFactor * 0.12,
      );
      (potatoMat.uniforms.uShadowTint.value as Voxl.Color).setRGB(
        0.18 + dayFactor * 0.26,
        0.22 + dayFactor * 0.34,
        0.34 + dayFactor * 0.38,
      );
      potatoMat.uniforms.uFogEnabled.value = cfg.fogMode !== 'off' ? 1.0 : 0.0;
      (potatoMat.uniforms.uFogColor.value as Voxl.Color).copy(fogColorObj);
      potatoMat.uniforms.uFogNear.value = cfg.fogMode === 'exp2' ? 14.0 : 22.0;
      potatoMat.uniforms.uFogFar.value = cfg.fogMode === 'exp2' ? 62.0 : 86.0;
      potatoMat.uniforms.uEnableGpuLod.value = cfg.gpuLod ? 1.0 : 0.0;
      potatoMat.uniformsNeedUpdate = true;

      if (prevGpuLod !== cfg.gpuLod || prevShaderMode !== cfg.shaderMode) {
        prevGpuLod = cfg.gpuLod;
        prevShaderMode = cfg.shaderMode;
        chunkBatcher.markDirty();
      }

      // G. GPU Frustum Culling (WebGL2 Transform Feedback + CPU fallback)
      const visibility = cfg.gpuCulling ? gpuCuller.cullSpheres(chunkSpheres, camera) : null;

      let visCount = 0;
      activeBatchChunks.length = 0;

      for (let i = 0; i < chunkList.length; i++) {
        const rec = chunkList[i];
        const isVisible = visibility ? visibility[i] > 0.5 : true;
        if (isVisible) visCount++;

        const dist = rec.worldSphere.center.distanceTo(camera.position);
        const useLod1Geo = cfg.gpuLod && dist > 26 && rec.lod1Geo !== null;

        if (cfg.chunkBatching) {
          if (rec.opaqueMesh) rec.opaqueMesh.visible = false;
          if (isVisible) {
            if (cfg.gpuLod && cfg.shaderMode === 'potato') {
              // Single-draw-call GPU LOD: include both LOD0 & LOD1 in merged buffer, vertex shader selects by distance!
              if (rec.batchEntry) activeBatchChunks.push(rec.batchEntry);
              if (rec.lod1BatchEntry) activeBatchChunks.push(rec.lod1BatchEntry);
            } else if (useLod1Geo && rec.lod1BatchEntry) {
              activeBatchChunks.push(rec.lod1BatchEntry);
            } else if (rec.batchEntry) {
              activeBatchChunks.push(rec.batchEntry);
            }
          }
        } else {
          if (rec.opaqueMesh) {
            rec.opaqueMesh.visible = isVisible;
            rec.opaqueMesh.material = activeOpaqueMat;
            const targetGeo = useLod1Geo && rec.lod1Geo ? rec.lod1Geo : rec.opaqueGeo;
            if (targetGeo && rec.opaqueMesh.geometry !== targetGeo) {
              rec.opaqueMesh.geometry = targetGeo;
            }
          }
        }

        if (rec.transMesh) {
          rec.transMesh.visible = isVisible;
        }
      }
      lastVisibleChunks = visCount;

      if (cfg.chunkBatching) {
        chunkBatcher.mesh.visible = true;
        chunkBatcher.mergedMaterial = activeOpaqueMat;
        chunkBatcher.mesh.material = activeOpaqueMat;
        // Update merged geometry (pass no renderer so Scene / RenderPass draws chunkBatcher.mesh in 1 call!)
        chunkBatcher.update(activeBatchChunks, camera);
      } else {
        chunkBatcher.mesh.visible = false;
      }

      // H. SoA Physics Debris (VoxelWorld -> InstancedMesh)
      if (cfg.soaDebris) {
        world.stepDebrisPhysics(dt);
        const vw = world.voxlWorld;
        let idx = 0;
        vw.forEachAllDebris((slot) => {
          if (idx >= debrisCapacity) return;
          const i3 = slot * 3;
          const size = vw.debrisSizes[slot];
          tempPos.set(vw.debrisPositions[i3], vw.debrisPositions[i3 + 1], vw.debrisPositions[i3 + 2]);
          const spin = vw.debrisResting[slot] ? 0 : elapsed * 4.5 + slot;
          tempEuler.set(spin, spin * 1.3, 0);
          tempQuat.setFromEuler(tempEuler);
          tempScale.set(size, size, size);
          tempMat.compose(tempPos, tempQuat, tempScale);
          debrisInstanced.setMatrixAt(idx, tempMat);
          tempColor.setHex(vw.debrisColors[slot]);
          debrisInstanced.setColorAt(idx, tempColor);
          idx++;
        });
        debrisInstanced.count = idx;
        debrisInstanced.visible = idx > 0;
        if (idx > 0) {
          debrisInstanced.instanceMatrix.needsUpdate = true;
          if (debrisInstanced.instanceColor) debrisInstanced.instanceColor.needsUpdate = true;
        }
      } else {
        debrisInstanced.visible = false;
      }

      // I. Instanced Foliage Toggle
      foliageInstanced.visible = cfg.instancedFoliage && foliageCount > 0;

      // J. Render via Direct WebGLRenderer OR EffectComposer Post-Processing Pipeline
      const renderStart = performance.now();
      renderer.info.reset();
      if (cfg.postProcessing) {
        bloomPass.enabled = cfg.bloomPass;
        vignettePass.enabled = cfg.vignettePass;
        retroPass.enabled = cfg.retroPixelPass;
        outputPass.enabled = true;
        composer.render(dt);
      } else {
        renderer.render(scene, camera);
      }
      const renderMs = performance.now() - renderStart;

      lastDrawCalls = renderer.info.render.calls;
      lastTriangles = renderer.info.render.triangles;
      profiler.recordRenderPassStats(lastDrawCalls, lastTriangles, true);
      profiler.endFrame({
        frameDeltaMs,
        physicsTotalMs: 0,
        physicsSteps: 1,
        renderMs,
        worldUpdateMs: 0,
        debrisUpdateMs: 0,
        activeBodies: 0,
        totalBodies: 0,
        activeDebris: world.voxlWorld.activeDebrisCount,
        visibleChunks: lastVisibleChunks,
        dirtyChunks: dirtyCount,
      });

      // K. Throttled HUD Telemetry Refresh (~5Hz to keep React zero-overhead)
      hudTimer += dt;
      if (hudTimer >= 0.2) {
        hudTimer = 0;
        const summary = profiler.getSnapshot();
        const targetName = currentHit ? (MC_BLOCK_BY_ID[currentHit.materialId]?.name ?? 'Block') : null;
        setStats({
          fps: Math.round(summary.fps),
          frameMs: Number(summary.frameTimeMs.toFixed(1)),
          drawCalls: lastDrawCalls,
          triangles: lastTriangles,
          visibleChunks: lastVisibleChunks,
          totalChunks: chunkList.length,
          activeDebris: world.voxlWorld.activeDebrisCount,
          gpuCullerActive: gpuCuller.isGPUActive,
          targetBlockName: targetName,
          playerPos: `${Math.floor(player.position.x)}, ${Math.floor(player.position.y)}, ${Math.floor(player.position.z)}`,
        });
      }
    };

    rafId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mousedown', onMouseDown);
      canvas.removeEventListener('dblclick', onDblClick);
      canvas.removeEventListener('contextmenu', onContextMenu);
      document.removeEventListener('pointerlockchange', onPointerLockChange);

      chunkBatcher.dispose();
      gpuCuller.dispose();
      composer.dispose();
      blockTex.dispose();
      potatoMat.dispose();
      lambertMat.dispose();
      basicMat.dispose();
      transparentMat.dispose();
      debrisGeo.dispose();
      debrisMat.dispose();
      foliageGeo.dispose();
      foliageMat.dispose();
      cursorBoxGeo.dispose();
      cursorEdgesGeo.dispose();
      cursorMat.dispose();
      sunOrbGeo.dispose();
      sunOrbMat.dispose();
      world.dispose();
      renderer.dispose();
    };
  }, [seed]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none font-sans text-slate-100">
      {/* WebGL2 Canvas Mount */}
      <div ref={mountRef} className="w-full h-full cursor-crosshair" />

      {/* Center Crosshair */}
      <div className="pointer-events-none fixed inset-0 flex items-center justify-center z-10">
        <div className="relative w-5 h-5">
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 bg-white/90 shadow-[0_0_2px_rgba(0,0,0,0.9)]" />
          <div className="absolute top-1/2 left-0 right-0 h-0.5 -translate-y-1/2 bg-white/90 shadow-[0_0_2px_rgba(0,0,0,0.9)]" />
        </div>
      </div>

      {/* Top-Left Branding + PerfProfiler Telemetry HUD */}
      <div className="fixed top-3 left-3 z-20 flex flex-col gap-2 max-w-[300px]">
        <div className="flex items-center gap-2 bg-slate-950/82 backdrop-blur-md border border-slate-700/70 rounded-lg px-3 py-2 shadow-lg">
          <Box className="w-4 h-4 text-emerald-400 shrink-0" />
          <div className="leading-tight">
            <div className="text-xs font-bold tracking-wider uppercase text-white">
              VoxlCraft <span className="text-emerald-400 font-semibold">Engine Demo</span>
            </div>
            <div className="text-[10px] text-slate-400">
              Standalone <code className="text-slate-200">src/voxl</code> Showcase
            </div>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <a
              href="/voxl-engine.zip"
              download="voxl-engine.zip"
              data-testid="download-voxl-zip"
              className="flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded bg-emerald-600/90 hover:bg-emerald-500 text-white border border-emerald-400/60 transition-colors cursor-pointer"
              title="Download standalone Voxl engine + docs + example (.zip)"
            >
              <Download className="w-3 h-3" />
              .zip
            </a>
            {onExitToVoxelMakers && (
              <button
                type="button"
                onClick={onExitToVoxelMakers}
                className="flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600/80 transition-colors cursor-pointer"
                title="Return to VoxelMakers"
              >
                <ArrowLeft className="w-3 h-3" />
                VoxelMakers
              </button>
            )}
          </div>
        </div>

        {toggles.perfHud && (
          <div className="bg-slate-950/80 backdrop-blur-md border border-slate-700/70 rounded-lg px-3 py-2 text-[11px] font-mono shadow-lg space-y-1">
            <div className="flex items-center justify-between text-slate-300 border-b border-slate-800 pb-1">
              <span className="flex items-center gap-1.5 font-semibold text-emerald-400">
                <Cpu className="w-3.5 h-3.5" /> PerfProfiler
              </span>
              <span className="text-slate-400">
                {stats.fps} FPS · {stats.frameMs}ms
              </span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Draw Calls</span>
                <span
                  data-testid="voxl-draw-calls"
                  className={toggles.chunkBatching ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}
                >
                  {stats.drawCalls}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Triangles</span>
                <span className="text-slate-200">{stats.triangles.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Chunks</span>
                <span className="text-sky-300">
                  {stats.visibleChunks}/{stats.totalChunks}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SoA Debris</span>
                <span data-testid="voxl-debris-count" className="text-orange-300">
                  {stats.activeDebris}
                </span>
              </div>
              <div className="flex justify-between col-span-2 pt-0.5 border-t border-slate-800/80">
                <span className="text-slate-400">Culler</span>
                <span className="text-slate-200">
                  {!toggles.gpuCulling
                    ? 'Disabled'
                    : stats.gpuCullerActive
                      ? 'WebGL2 Transform Feedback'
                      : 'Frustum CPU Fallback'}
                </span>
              </div>
              <div className="flex justify-between col-span-2">
                <span className="text-slate-400">Pos / Target</span>
                <span className="text-slate-200 truncate max-w-[165px]">
                  {stats.playerPos}
                  {stats.targetBlockName ? ` · ${stats.targetBlockName}` : ''}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Quick Controls Hint */}
        <div className="bg-slate-950/72 backdrop-blur-sm border border-slate-800/80 rounded-lg px-2.5 py-1.5 text-[10px] text-slate-300 leading-relaxed">
          <span className="text-white font-semibold">WASD</span> Move ·{' '}
          <span className="text-white font-semibold">Space</span> Jump/Up ·{' '}
          <span className="text-white font-semibold">Drag / DblClick</span> Look ·{' '}
          <span className="text-white font-semibold">LMB/RMB</span> Break/Place ·{' '}
          <span className="text-white font-semibold">F</span> TNT ·{' '}
          <span className="text-white font-semibold">Tab</span> Features
          {isPointerLocked && <span className="ml-1 text-emerald-400">(Mouse Locked — Esc to unlock)</span>}
        </div>
      </div>

      {/* Top-Right Feature Panel Toggle Button (when collapsed) */}
      {!panelOpen && (
        <button
          type="button"
          onClick={() => setPanelOpen(true)}
          className="fixed top-3 right-3 z-20 flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-950/85 hover:bg-slate-900 border border-slate-700/80 text-xs font-semibold text-white shadow-lg cursor-pointer"
        >
          <Sliders className="w-4 h-4 text-emerald-400" />
          Voxl Features
        </button>
      )}

      {/* Right Collapsible Voxl Engine Feature Toggles Drawer */}
      {panelOpen && (
        <aside
          data-testid="voxl-feature-panel"
          className="fixed top-3 right-3 bottom-3 z-20 w-[300px] bg-slate-950/88 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-2xl flex flex-col overflow-hidden"
        >
          <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-slate-800 bg-slate-900/70">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold tracking-wide uppercase text-white">
                Voxl Engine Features
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPanelOpen(false)}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              title="Hide panel (Tab)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-4 text-xs">
            {/* Quick Actions */}
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                data-testid="btn-detonate-tnt"
                onClick={() => actionsRef.current.detonateTnt()}
                className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-md bg-rose-600/90 hover:bg-rose-500 text-white font-semibold text-[11px] transition-colors cursor-pointer"
              >
                <Flame className="w-3.5 h-3.5" /> TNT [F]
              </button>
              <button
                type="button"
                onClick={() => setSeed((s) => s + 137)}
                className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" /> Seed
              </button>
              <button
                type="button"
                onClick={() => actionsRef.current.resetPlayer()}
                className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" /> Spawn
              </button>
            </div>

            {/* Section 1: Rendering & Batching */}
            <section className="space-y-2">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <Layers className="w-3 h-3 text-emerald-400" /> Rendering &amp; Voxel Meshing
              </div>

              <ToggleRow
                testId="toggle-chunk-batching"
                label="ChunkBatchRenderer"
                hint="Merge visible chunks → 1 draw call"
                checked={toggles.chunkBatching}
                onChange={(v) => updateToggle('chunkBatching', v)}
              />
              <ToggleRow
                testId="toggle-gpu-culling"
                label="GPUChunkCuller"
                hint="WebGL2 Transform Feedback frustum cull"
                checked={toggles.gpuCulling}
                onChange={(v) => updateToggle('gpuCulling', v)}
              />
              <ToggleRow
                testId="toggle-baked-ao"
                label="Baked Vertex AO"
                hint="4-sample crevice shadowing in mesher"
                checked={toggles.bakedAO}
                onChange={(v) => updateToggle('bakedAO', v)}
              />
              <ToggleRow
                testId="toggle-gpu-lod"
                label="Distance / GPU LOD"
                hint="LOD0 near (<26m) + LOD1 far"
                checked={toggles.gpuLod}
                onChange={(v) => updateToggle('gpuLod', v)}
              />

              {/* Shader Mode Selector */}
              <div className="pt-1">
                <div className="text-[11px] font-medium text-slate-300 mb-1.5">Shader / Material Pipeline</div>
                <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {(
                    [
                      ['potato', 'Potato'],
                      ['lambert', 'Lambert'],
                      ['basic', 'Basic'],
                    ] as const
                  ).map(([mode, label]) => (
                    <button
                      key={mode}
                      type="button"
                      data-testid={`shader-mode-${mode}`}
                      onClick={() => updateToggle('shaderMode', mode)}
                      className={`py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                        toggles.shaderMode === mode
                          ? 'bg-emerald-500 text-slate-950'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <ToggleRow
                testId="toggle-procedural-tex"
                label="Procedural CanvasTexture"
                hint="16×16 grain texture (Lambert / Basic)"
                checked={toggles.proceduralTexture}
                onChange={(v) => updateToggle('proceduralTexture', v)}
              />
            </section>

            {/* Section 2: Atmosphere & Lighting */}
            <section className="space-y-2 border-t border-slate-800/80 pt-3">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <Sun className="w-3 h-3 text-amber-400" /> Atmosphere &amp; Lighting
              </div>

              <div>
                <div className="text-[11px] font-medium text-slate-300 mb-1.5">Atmospheric Fog</div>
                <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {(
                    [
                      ['linear', 'Fog'],
                      ['exp2', 'FogExp2'],
                      ['off', 'Off'],
                    ] as const
                  ).map(([mode, label]) => (
                    <button
                      key={mode}
                      type="button"
                      data-testid={`fog-mode-${mode}`}
                      onClick={() => updateToggle('fogMode', mode)}
                      className={`py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                        toggles.fogMode === mode
                          ? 'bg-sky-400 text-slate-950'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <ToggleRow
                testId="toggle-day-night"
                label="Animated Day / Night"
                hint="Orbits DirectionalLight + sky tint"
                checked={toggles.dayNightCycle}
                onChange={(v) => updateToggle('dayNightCycle', v)}
              />

              {!toggles.dayNightCycle && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <span className="flex items-center gap-1">
                      <Sun className="w-3 h-3 text-amber-400" /> Sun Time
                    </span>
                    <span className="text-slate-400 font-mono flex items-center gap-1">
                      {toggles.timeOfDay > 0.55 ? (
                        <>
                          <Moon className="w-3 h-3 text-indigo-300" /> Night
                        </>
                      ) : toggles.timeOfDay > 0.45 ? (
                        'Sunset'
                      ) : (
                        'Day'
                      )}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.05}
                    max={0.85}
                    step={0.01}
                    value={toggles.timeOfDay}
                    onChange={(e) => updateToggle('timeOfDay', parseFloat(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>
              )}

              <ToggleRow
                testId="toggle-point-lights"
                label="Torch PointLights"
                hint="3 flickering watchtower lights"
                checked={toggles.pointLights}
                onChange={(v) => updateToggle('pointLights', v)}
              />
            </section>

            {/* Section 3: EffectComposer Post-Processing */}
            <section className="space-y-2 border-t border-slate-800/80 pt-3">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <Sparkles className="w-3 h-3 text-violet-400" /> EffectComposer Post-FX
              </div>

              <ToggleRow
                testId="toggle-post-processing"
                label="EffectComposer Pipeline"
                hint="RenderPass + ShaderPass + OutputPass"
                checked={toggles.postProcessing}
                onChange={(v) => updateToggle('postProcessing', v)}
              />

              {toggles.postProcessing && (
                <div className="pl-2.5 border-l-2 border-violet-500/40 space-y-1.5">
                  <ToggleRow
                    testId="toggle-bloom"
                    label="HDR Bloom Pass"
                    hint="Glows sky & emissive Glowstone"
                    checked={toggles.bloomPass}
                    onChange={(v) => updateToggle('bloomPass', v)}
                  />
                  <ToggleRow
                    testId="toggle-vignette"
                    label="Cinematic Vignette"
                    hint="S-curve contrast + edge vignette"
                    checked={toggles.vignettePass}
                    onChange={(v) => updateToggle('vignettePass', v)}
                  />
                  <ToggleRow
                    testId="toggle-retro-pixel"
                    label="Retro Pixel ShaderPass"
                    hint="4× pixelation + color quantization"
                    checked={toggles.retroPixelPass}
                    onChange={(v) => updateToggle('retroPixelPass', v)}
                  />
                </div>
              )}
            </section>

            {/* Section 4: World SoA, Instancing & Controls */}
            <section className="space-y-2 border-t border-slate-800/80 pt-3">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                <Compass className="w-3 h-3 text-cyan-400" /> World SoA &amp; Scene Objects
              </div>

              <ToggleRow
                testId="toggle-soa-debris"
                label="VoxelWorld SoA Debris"
                hint="InstancedMesh physical block shards"
                checked={toggles.soaDebris}
                onChange={(v) => updateToggle('soaDebris', v)}
              />
              <ToggleRow
                testId="toggle-foliage"
                label="Instanced Foliage"
                hint="InstancedMesh grass & wildflowers"
                checked={toggles.instancedFoliage}
                onChange={(v) => updateToggle('instancedFoliage', v)}
              />
              <ToggleRow
                testId="toggle-wireframe-cursor"
                label="Raycast Block Cursor"
                hint="DDA raycast + LineSegments wireframe"
                checked={toggles.wireframeCursor}
                onChange={(v) => updateToggle('wireframeCursor', v)}
              />
              <ToggleRow
                testId="toggle-fly-mode"
                label="Creative Fly Mode"
                hint="Space = Up · C / Ctrl = Down"
                checked={toggles.flyMode}
                onChange={(v) => updateToggle('flyMode', v)}
              />
              <ToggleRow
                testId="toggle-perf-hud"
                label="PerfProfiler HUD"
                hint="Show live FPS & draw-call metrics"
                checked={toggles.perfHud}
                onChange={(v) => updateToggle('perfHud', v)}
              />
            </section>
          </div>
        </aside>
      )}

      {/* Bottom-Center 8-Slot Block Hotbar */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 bg-slate-950/85 backdrop-blur-md border border-slate-700/80 rounded-xl px-2.5 py-2 shadow-2xl">
        {MC_HOTBAR_BLOCKS.map((block, idx) => {
          const active = selectedSlot === idx;
          return (
            <button
              key={block.id}
              type="button"
              onClick={() => setSelectedSlot(idx)}
              className={`relative flex flex-col items-center justify-center w-12 h-12 rounded-lg border transition-all cursor-pointer ${
                active
                  ? 'border-emerald-400 bg-slate-800/95 scale-105 shadow-[0_0_12px_rgba(52,211,153,0.35)]'
                  : 'border-slate-700/70 bg-slate-900/70 hover:bg-slate-800/70'
              }`}
              title={`${block.name} (Key ${block.key})`}
            >
              <span className="absolute top-0.5 left-1 text-[9px] font-mono text-slate-400">
                {block.key}
              </span>
              <span
                className="w-5 h-5 rounded-sm border border-black/40 shadow-inner"
                style={{
                  background: block.topColor
                    ? `linear-gradient(180deg, ${block.cssColor} 45%, #${block.color.toString(16).padStart(6, '0')} 45%)`
                    : block.cssColor,
                }}
              />
              <span className="mt-1 text-[9px] font-medium text-slate-200 truncate max-w-[44px]">
                {block.name.split(' ')[0]}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

interface ToggleRowProps {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  testId?: string;
}

const ToggleRow: React.FC<ToggleRowProps> = ({ label, hint, checked, onChange, testId }) => (
  <button
    type="button"
    data-testid={testId}
    onClick={() => onChange(!checked)}
    className="w-full flex items-center justify-between gap-2 text-left py-1 px-1.5 rounded-md hover:bg-slate-800/60 transition-colors cursor-pointer"
  >
    <div className="min-w-0">
      <div className="text-[11px] font-medium text-slate-100 leading-tight">{label}</div>
      <div className="text-[10px] text-slate-400 truncate">{hint}</div>
    </div>
    <div
      className={`relative w-8 h-4.5 rounded-full shrink-0 transition-colors ${
        checked ? 'bg-emerald-500' : 'bg-slate-700'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-4' : 'translate-x-0.5'
        }`}
      />
    </div>
  </button>
);

export default MinecraftDemo;
