/**
 * VoxlCraft — Standalone Minecraft Clone World & Physics Engine
 * Built 100% on the extracted Voxl engine (`src/voxl`) with ZERO imports from VoxelMakers (`src/game`).
 */
import * as Voxl from '../../src';

export const MC_CHUNK_SIZE = 16;
export const MC_CHUNK_HEIGHT = 32;
export const MC_WATER_LEVEL = 10;

export const MC_BLOCK = {
  AIR: 0,
  GRASS: 1,
  DIRT: 2,
  STONE: 3,
  WOOD: 4,
  LEAVES: 5,
  SAND: 6,
  WATER: 7,
  GLASS: 8,
  METAL: 9,
  TNT: 10,
  GLOWSTONE: 11,
} as const;

export type McBlockId = (typeof MC_BLOCK)[keyof typeof MC_BLOCK];

export interface McBlockMeta {
  id: McBlockId;
  name: string;
  key: string;
  color: number;
  topColor?: number;
  bottomColor?: number;
  cssColor: string;
  shaderMatId: number;
  transparent?: boolean;
  emissiveBoost?: number;
  hotbar?: boolean;
}

export const MC_BLOCK_LIST: ReadonlyArray<McBlockMeta> = [
  {
    id: MC_BLOCK.GRASS,
    name: 'Grass',
    key: '1',
    color: 0x7c5c3e,
    topColor: 0x52a83e,
    bottomColor: 0x735235,
    cssColor: '#52a83e',
    shaderMatId: Voxl.VOXEL_MAT_GRASS,
    hotbar: true,
  },
  {
    id: MC_BLOCK.DIRT,
    name: 'Dirt',
    key: '2',
    color: 0x865d3b,
    cssColor: '#865d3b',
    shaderMatId: Voxl.VOXEL_MAT_DIRT,
    hotbar: true,
  },
  {
    id: MC_BLOCK.STONE,
    name: 'Stone',
    key: '3',
    color: 0x838b94,
    cssColor: '#838b94',
    shaderMatId: Voxl.VOXEL_MAT_STONE,
    hotbar: true,
  },
  {
    id: MC_BLOCK.WOOD,
    name: 'Oak Wood',
    key: '4',
    color: 0x9c6e44,
    topColor: 0xb68a5c,
    cssColor: '#9c6e44',
    shaderMatId: Voxl.VOXEL_MAT_WOOD,
    hotbar: true,
  },
  {
    id: MC_BLOCK.LEAVES,
    name: 'Leaves',
    key: '5',
    color: 0x357a2e,
    cssColor: '#357a2e',
    shaderMatId: Voxl.VOXEL_MAT_GRASS,
    hotbar: true,
  },
  {
    id: MC_BLOCK.GLASS,
    name: 'Glass',
    key: '6',
    color: 0x9ee6ff,
    cssColor: '#9ee6ff',
    shaderMatId: Voxl.VOXEL_MAT_GLASS,
    transparent: true,
    hotbar: true,
  },
  {
    id: MC_BLOCK.METAL,
    name: 'Iron Block',
    key: '7',
    color: 0xc2cedb,
    cssColor: '#c2cedb',
    shaderMatId: Voxl.VOXEL_MAT_METAL,
    hotbar: true,
  },
  {
    id: MC_BLOCK.TNT,
    name: 'TNT',
    key: '8',
    color: 0xd93829,
    topColor: 0xe5d9c3,
    cssColor: '#d93829',
    shaderMatId: Voxl.VOXEL_MAT_DEFAULT,
    hotbar: true,
  },
  {
    id: MC_BLOCK.SAND,
    name: 'Sand',
    key: '',
    color: 0xdecb86,
    cssColor: '#decb86',
    shaderMatId: Voxl.VOXEL_MAT_DIRT,
  },
  {
    id: MC_BLOCK.WATER,
    name: 'Water',
    key: '',
    color: 0x2b8be0,
    cssColor: '#2b8be0',
    shaderMatId: Voxl.VOXEL_MAT_GLASS,
    transparent: true,
  },
  {
    id: MC_BLOCK.GLOWSTONE,
    name: 'Glowstone',
    key: '',
    color: 0xffd76a,
    cssColor: '#ffd76a',
    shaderMatId: Voxl.VOXEL_MAT_DEFAULT,
    emissiveBoost: 1.35,
  },
];

export const MC_HOTBAR_BLOCKS = MC_BLOCK_LIST.filter((b) => b.hotbar);

export const MC_MESHER_PALETTE: Record<number, Voxl.VoxelMesherPaletteEntry> = Object.fromEntries(
  MC_BLOCK_LIST.map((b) => [
    b.id,
    {
      color: b.color,
      topColor: b.topColor,
      bottomColor: b.bottomColor,
      shaderMatId: b.shaderMatId,
      transparent: b.transparent,
      emissiveBoost: b.emissiveBoost,
    },
  ]),
);

export const MC_BLOCK_BY_ID: Record<number, McBlockMeta> = Object.fromEntries(
  MC_BLOCK_LIST.map((b) => [b.id, b]),
);

function hash2D(x: number, z: number, seed: number): number {
  let n = Math.imul(x, 374761393) + Math.imul(z, 668265263) + Math.imul(seed, 1442695041);
  n = (n ^ (n >>> 13)) >>> 0;
  n = Math.imul(n, 1274126177) >>> 0;
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function smoothNoise2D(x: number, z: number, seed: number): number {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const xf = x - xi;
  const zf = z - zi;
  const u = xf * xf * (3 - 2 * xf);
  const v = zf * zf * (3 - 2 * zf);

  const a = hash2D(xi, zi, seed);
  const b = hash2D(xi + 1, zi, seed);
  const c = hash2D(xi, zi + 1, seed);
  const d = hash2D(xi + 1, zi + 1, seed);

  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm2D(x: number, z: number, seed: number): number {
  let value = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < 4; i++) {
    value += smoothNoise2D(x * freq, z * freq, seed + i * 97) * amp;
    freq *= 2.02;
    amp *= 0.5;
  }
  return value;
}

export interface MinecraftChunkRecord {
  cx: number;
  cz: number;
  chunkId: number;
  slot: number;
  originX: number;
  originZ: number;
  opaqueGeo: Voxl.BufferGeometry | null;
  lod1Geo: Voxl.BufferGeometry | null;
  transGeo: Voxl.BufferGeometry | null;
  opaqueMesh: Voxl.Mesh | null;
  transMesh: Voxl.Mesh | null;
  batchEntry: Voxl.BatchableChunk | null;
  lod1BatchEntry: Voxl.BatchableChunk | null;
  worldSphere: Voxl.Sphere;
}

export interface TorchLocation {
  x: number;
  y: number;
  z: number;
}

export interface FoliageSample {
  x: number;
  y: number;
  z: number;
  color: number;
  scaleY: number;
}

export interface MinecraftPlayerState {
  position: Voxl.Vector3;
  velocity: Voxl.Vector3;
  yaw: number;
  pitch: number;
  onGround: boolean;
  inWater: boolean;
  flyMode: boolean;
}

export class MinecraftWorldController {
  public readonly voxlWorld: Voxl.VoxelWorld;
  public readonly radiusChunks: number;
  public readonly seed: number;
  public readonly chunks = new Map<string, MinecraftChunkRecord>();
  public readonly torches: TorchLocation[] = [];
  public readonly foliage: FoliageSample[] = [];
  public spawnPoint = new Voxl.Vector3(0.5, 18, 0.5);

  constructor(radiusChunks = 3, seed = 1337) {
    this.radiusChunks = radiusChunks;
    this.seed = seed;
    const gridSpan = radiusChunks * 2 + 1;
    this.voxlWorld = new Voxl.VoxelWorld({
      maxChunks: gridSpan * gridSpan + 8,
      maxBodies: 16,
      maxDebris: 450,
      chunkX: MC_CHUNK_SIZE,
      chunkY: MC_CHUNK_HEIGHT,
      chunkZ: MC_CHUNK_SIZE,
    });
    this.generateInitialWorld();
  }

  public chunkKey(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  public getTerrainHeight(wx: number, wz: number): number {
    // Carve a scenic lake basin slightly northeast of spawn and rolling hills around it
    const lakeDx = wx - 14;
    const lakeDz = wz + 16;
    const lakeDist = Math.hypot(lakeDx, lakeDz);
    const lakeCarve = lakeDist < 14 ? (1 - lakeDist / 14) * 5.2 : 0;

    // Gentle flat clearing right around player spawn (0, 6) & watchtower (0, -12)
    const spawnDist = Math.hypot(wx, wz + 2);
    const spawnFlatten = Math.max(0, 1 - spawnDist / 18);

    const n = fbm2D((wx + 512) * 0.028, (wz + 512) * 0.028, this.seed);
    const ridge = fbm2D((wx - 256) * 0.06, (wz + 256) * 0.06, this.seed + 555);
    const rawH = 7 + n * 14 + Math.max(0, ridge - 0.52) * 10 - lakeCarve;
    const blended = rawH * (1 - spawnFlatten * 0.88) + 12.2 * (spawnFlatten * 0.88);
    return Math.max(2, Math.min(MC_CHUNK_HEIGHT - 6, Math.floor(blended)));
  }

  private generateInitialWorld(): void {
    const r = this.radiusChunks;
    for (let cz = -r; cz <= r; cz++) {
      for (let cx = -r; cx <= r; cx++) {
        const chunkId = Voxl.encodeChunkId(cx, cz);
        const originX = cx * MC_CHUNK_SIZE;
        const originZ = cz * MC_CHUNK_SIZE;
        const slot = this.voxlWorld.acquireChunkSlot(chunkId, originX, 0, originZ, {
          allocateDamage: true,
        });
        if (slot < 0) continue;

        const worldSphere = new Voxl.Sphere(
          new Voxl.Vector3(originX + MC_CHUNK_SIZE * 0.5, MC_CHUNK_HEIGHT * 0.5, originZ + MC_CHUNK_SIZE * 0.5),
          Math.hypot(MC_CHUNK_SIZE * 0.5, MC_CHUNK_HEIGHT * 0.5, MC_CHUNK_SIZE * 0.5) + 1,
        );
        this.chunks.set(this.chunkKey(cx, cz), {
          cx,
          cz,
          chunkId,
          slot,
          originX,
          originZ,
          opaqueGeo: null,
          lod1Geo: null,
          transGeo: null,
          opaqueMesh: null,
          transMesh: null,
          batchEntry: null,
          lod1BatchEntry: null,
          worldSphere,
        });
      }
    }

    // Pass 1: Terrain strata + water + sand shores
    for (const rec of this.chunks.values()) {
      for (let lz = 0; lz < MC_CHUNK_SIZE; lz++) {
        const wz = rec.originZ + lz;
        for (let lx = 0; lx < MC_CHUNK_SIZE; lx++) {
          const wx = rec.originX + lx;
          const h = this.getTerrainHeight(wx, wz);

          for (let wy = 0; wy <= h; wy++) {
            let block: McBlockId = MC_BLOCK.STONE;
            if (wy === h) {
              block = h <= MC_WATER_LEVEL + 1 ? MC_BLOCK.SAND : MC_BLOCK.GRASS;
            } else if (wy >= h - 3) {
              block = h <= MC_WATER_LEVEL + 1 ? MC_BLOCK.SAND : MC_BLOCK.DIRT;
            } else if (wy >= 2 && hash2D(wx * 3 + wy, wz * 5 - wy, this.seed + 909) > 0.96) {
              block = MC_BLOCK.METAL;
            }
            this.voxlWorld.setVoxel(wx, wy, wz, block);
          }

          if (h < MC_WATER_LEVEL) {
            for (let wy = h + 1; wy <= MC_WATER_LEVEL; wy++) {
              this.voxlWorld.setVoxel(wx, wy, wz, MC_BLOCK.WATER);
            }
          }
        }
      }
    }

    // Pass 2: Trees & Instanced foliage samples
    for (const rec of this.chunks.values()) {
      for (let lz = 2; lz < MC_CHUNK_SIZE - 2; lz += 2) {
        for (let lx = 2; lx < MC_CHUNK_SIZE - 2; lx += 2) {
          const wx = rec.originX + lx;
          const wz = rec.originZ + lz;
          // Keep spawn and watchtower clearing open
          if (Math.abs(wx) <= 7 && wz >= -18 && wz <= 5) continue;

          const h = this.getTerrainHeight(wx, wz);
          if (h <= MC_WATER_LEVEL + 1 || h >= MC_CHUNK_HEIGHT - 8) continue;

          const treeRoll = hash2D(wx, wz, this.seed + 313);
          if (treeRoll > 0.955) {
            this.stampTree(wx, h + 1, wz, treeRoll > 0.98 ? 5 : 4);
          } else if (treeRoll < 0.24 && this.foliage.length < 900) {
            const flowerRoll = hash2D(wx + 19, wz - 23, this.seed + 717);
            const color =
              flowerRoll > 0.86
                ? 0xf43f5e
                : flowerRoll > 0.72
                  ? 0xfacc15
                  : flowerRoll > 0.62
                    ? 0x38bdf8
                    : 0x4ca638;
            this.foliage.push({
              x: wx + 0.5,
              y: h + 1,
              z: wz + 0.5,
              color,
              scaleY: flowerRoll > 0.62 ? 0.55 : 0.42 + (treeRoll * 1.4),
            });
          }
        }
      }
    }

    // Pass 3: Starter Stone & Glass Watchtower + TNT Demo Pile + Glowstone Torches right ahead of spawn (-Z)
    this.buildLandmarkShowcase();

    // Compute safe spawn looking toward -Z (the watchtower, TNT pile, lake & hills)
    const spawnGround = this.getHighestSolidY(1, 5);
    this.spawnPoint.set(1.5, spawnGround + 2.1, 5.5);
  }

  private stampTree(tx: number, baseY: number, tz: number, trunkHeight: number): void {
    for (let y = 0; y < trunkHeight; y++) {
      this.setBlock(tx, baseY + y, tz, MC_BLOCK.WOOD);
    }
    const topY = baseY + trunkHeight;
    for (let dy = -1; dy <= 2; dy++) {
      const radius = dy === 2 ? 1 : 2;
      for (let dz = -radius; dz <= radius; dz++) {
        for (let dx = -radius; dx <= radius; dx++) {
          if (Math.abs(dx) === radius && Math.abs(dz) === radius && dy >= 1) continue;
          const bx = tx + dx;
          const by = topY + dy;
          const bz = tz + dz;
          if (this.getBlock(bx, by, bz) === MC_BLOCK.AIR) {
            this.setBlock(bx, by, bz, MC_BLOCK.LEAVES);
          }
        }
      }
    }
  }

  private buildLandmarkShowcase(): void {
    const cx = 0;
    const cz = -12;
    const baseY = this.getTerrainHeight(cx, cz);

    // Level stone plaza
    for (let dz = -4; dz <= 4; dz++) {
      for (let dx = -4; dx <= 4; dx++) {
        const y0 = Math.min(baseY, this.getTerrainHeight(cx + dx, cz + dz));
        for (let y = y0; y <= baseY; y++) {
          this.setBlock(cx + dx, y, cz + dz, MC_BLOCK.STONE);
        }
        for (let y = baseY + 1; y <= baseY + 8; y++) {
          this.setBlock(cx + dx, y, cz + dz, MC_BLOCK.AIR);
        }
      }
    }

    // Hollow stone + glass + iron watchtower showing AO, transparency, metal Fresnel rim, and emissive glowstone
    for (let y = 1; y <= 6; y++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let dx = -2; dx <= 2; dx++) {
          const isEdge = Math.abs(dx) === 2 || Math.abs(dz) === 2;
          if (!isEdge) continue;
          const isCorner = Math.abs(dx) === 2 && Math.abs(dz) === 2;
          const isDoor = dz === 2 && dx === 0 && (y === 1 || y === 2);
          if (isDoor) continue;
          if (isCorner) {
            this.setBlock(cx + dx, baseY + y, cz + dz, y === 6 ? MC_BLOCK.GLOWSTONE : MC_BLOCK.WOOD);
          } else if (y === 3 || y === 4) {
            this.setBlock(cx + dx, baseY + y, cz + dz, MC_BLOCK.GLASS);
          } else if (y === 6) {
            this.setBlock(cx + dx, baseY + y, cz + dz, MC_BLOCK.METAL);
          } else {
            this.setBlock(cx + dx, baseY + y, cz + dz, MC_BLOCK.STONE);
          }
        }
      }
    }

    // Glowing lantern cap + torch point lights
    this.setBlock(cx, baseY + 7, cz, MC_BLOCK.GLOWSTONE);
    this.torches.push(
      { x: cx - 2, y: baseY + 7.2, z: cz + 2 },
      { x: cx + 2, y: baseY + 7.2, z: cz + 2 },
      { x: cx, y: baseY + 8.2, z: cz },
    );

    // TNT cluster to the left so player can immediately test explosions & SoA debris!
    const tntX = -6;
    const tntZ = -8;
    const tntY = this.getHighestSolidY(tntX, tntZ) + 1;
    this.setBlock(tntX, tntY, tntZ, MC_BLOCK.TNT);
    this.setBlock(tntX + 1, tntY, tntZ, MC_BLOCK.TNT);
    this.setBlock(tntX, tntY + 1, tntZ, MC_BLOCK.TNT);
  }

  public getBlock(wx: number, wy: number, wz: number): number {
    if (wy < 0 || wy >= MC_CHUNK_HEIGHT) return MC_BLOCK.AIR;
    return this.voxlWorld.getVoxel(wx, wy, wz);
  }

  public setBlock(wx: number, wy: number, wz: number, blockId: number): boolean {
    if (wy < 0 || wy >= MC_CHUNK_HEIGHT) return false;
    const slot = this.voxlWorld.getChunkSlotByWorld(wx, wy, wz);
    if (slot < 0) return false;
    this.voxlWorld.setVoxel(wx, wy, wz, blockId);

    // Also mark adjacent chunks dirty if editing on a chunk boundary so neighbor faces update cleanly
    const lx = ((wx % MC_CHUNK_SIZE) + MC_CHUNK_SIZE) % MC_CHUNK_SIZE;
    const lz = ((wz % MC_CHUNK_SIZE) + MC_CHUNK_SIZE) % MC_CHUNK_SIZE;
    const cx = Math.floor(wx / MC_CHUNK_SIZE);
    const cz = Math.floor(wz / MC_CHUNK_SIZE);
    const markNeighbor = (ncx: number, ncz: number) => {
      const nSlot = this.voxlWorld.getChunkSlotById(Voxl.encodeChunkId(ncx, ncz));
      if (nSlot >= 0) this.voxlWorld.markChunkDirty(nSlot);
    };
    if (lx === 0) markNeighbor(cx - 1, cz);
    if (lx === MC_CHUNK_SIZE - 1) markNeighbor(cx + 1, cz);
    if (lz === 0) markNeighbor(cx, cz - 1);
    if (lz === MC_CHUNK_SIZE - 1) markNeighbor(cx, cz + 1);
    return true;
  }

  public getHighestSolidY(wx: number, wz: number): number {
    for (let y = MC_CHUNK_HEIGHT - 1; y >= 0; y--) {
      const id = this.getBlock(wx, y, wz);
      if (id !== MC_BLOCK.AIR && id !== MC_BLOCK.WATER) {
        return y;
      }
    }
    return 1;
  }

  public isSolidCollider(wx: number, wy: number, wz: number): boolean {
    const id = this.getBlock(wx, wy, wz);
    return id !== MC_BLOCK.AIR && id !== MC_BLOCK.WATER;
  }

  public raycastBlock(origin: Voxl.Vector3, dir: Voxl.Vector3, maxDist = 7.5): Voxl.VoxelDDARaycastHit | null {
    return Voxl.raycastVoxels(
      origin,
      dir,
      maxDist,
      (wx, wy, wz) => this.getBlock(wx, wy, wz),
      (id) => id !== MC_BLOCK.AIR && id !== MC_BLOCK.WATER,
    );
  }

  public breakBlock(wx: number, wy: number, wz: number, spawnDebris = true): number {
    const mat = this.getBlock(wx, wy, wz);
    if (mat === MC_BLOCK.AIR || mat === MC_BLOCK.WATER || wy <= 0) return 0;

    if (mat === MC_BLOCK.TNT) {
      return this.detonateExplosion(wx + 0.5, wy + 0.5, wz + 0.5, 3.6, spawnDebris);
    }

    this.setBlock(wx, wy, wz, MC_BLOCK.AIR);
    if (spawnDebris) {
      const meta = MC_BLOCK_BY_ID[mat];
      const color = meta?.topColor ?? meta?.color ?? 0xaaaaaa;
      for (let i = 0; i < 6; i++) {
        const vx = (Math.random() - 0.5) * 4.2;
        const vy = 2.4 + Math.random() * 3.2;
        const vz = (Math.random() - 0.5) * 4.2;
        this.voxlWorld.spawnDebris(
          wx + 0.25 + Math.random() * 0.5,
          wy + 0.25 + Math.random() * 0.5,
          wz + 0.25 + Math.random() * 0.5,
          vx,
          vy,
          vz,
          color,
          0.22 + Math.random() * 0.08,
          6.0,
        );
      }
    }
    return 1;
  }

  public detonateExplosion(
    cx: number,
    cy: number,
    cz: number,
    radius = 3.6,
    spawnDebris = true,
  ): number {
    this.voxlWorld.queueExplosion(cx, cy, cz, radius, 1200);
    const rCeil = Math.ceil(radius);
    const rSq = radius * radius;
    let broken = 0;

    for (let dy = -rCeil; dy <= rCeil; dy++) {
      const wy = Math.floor(cy) + dy;
      if (wy <= 0 || wy >= MC_CHUNK_HEIGHT) continue;
      for (let dz = -rCeil; dz <= rCeil; dz++) {
        const wz = Math.floor(cz) + dz;
        for (let dx = -rCeil; dx <= rCeil; dx++) {
          const wx = Math.floor(cx) + dx;
          const distSq = dx * dx + dy * dy + dz * dz;
          if (distSq > rSq) continue;

          const mat = this.getBlock(wx, wy, wz);
          if (mat === MC_BLOCK.AIR || mat === MC_BLOCK.WATER) continue;

          // Damage & destroy directly in VoxelWorld SoA chunk table
          this.voxlWorld.damageVoxel(wx, wy, wz, 255, 'explosion');
          this.setBlock(wx, wy, wz, MC_BLOCK.AIR);
          broken++;

          if (spawnDebris && broken <= 95 && Math.random() < 0.72) {
            const invLen = 1 / Math.max(0.5, Math.sqrt(distSq));
            const speed = 4.5 + Math.random() * 6.5;
            const meta = MC_BLOCK_BY_ID[mat];
            const color = meta?.topColor ?? meta?.color ?? 0x999999;
            this.voxlWorld.spawnDebris(
              wx + 0.5,
              wy + 0.5,
              wz + 0.5,
              dx * invLen * speed + (Math.random() - 0.5) * 2,
              Math.abs(dy * invLen) * speed + 3.5 + Math.random() * 3.5,
              dz * invLen * speed + (Math.random() - 0.5) * 2,
              color,
              0.24 + Math.random() * 0.14,
              7.5,
            );
          }
        }
      }
    }
    this.voxlWorld.drainExplosionEvents();
    return broken;
  }

  public stepDebrisPhysics(dt: number): void {
    const vw = this.voxlWorld;
    const g = -22.0;
    const toRelease: number[] = [];

    vw.forEachAllDebris((slot) => {
      vw.debrisLifetimes[slot] -= dt;
      if (vw.debrisLifetimes[slot] <= 0) {
        toRelease.push(slot);
        return;
      }
      if (vw.debrisResting[slot] === 1) return;

      const i3 = slot * 3;
      let px = vw.debrisPositions[i3];
      let py = vw.debrisPositions[i3 + 1];
      let pz = vw.debrisPositions[i3 + 2];
      let vx = vw.debrisVelocities[i3];
      let vy = vw.debrisVelocities[i3 + 1] + g * dt;
      let vz = vw.debrisVelocities[i3 + 2];

      const nextX = px + vx * dt;
      const nextY = py + vy * dt;
      const nextZ = pz + vz * dt;
      const half = vw.debrisSizes[slot] * 0.5;

      if (this.isSolidCollider(Math.floor(nextX), Math.floor(nextY - half), Math.floor(nextZ))) {
        if (Math.abs(vy) < 1.2) {
          vy = 0;
          vx *= 0.65;
          vz *= 0.65;
          if (vx * vx + vz * vz < 0.04) {
            vw.setDebrisResting(slot, true);
          }
        } else {
          vy = -vy * 0.38;
          vx *= 0.72;
          vz *= 0.72;
        }
        py = Math.floor(nextY - half) + 1 + half;
      } else {
        px = nextX;
        py = nextY;
        pz = nextZ;
      }

      vw.debrisPositions[i3] = px;
      vw.debrisPositions[i3 + 1] = py;
      vw.debrisPositions[i3 + 2] = pz;
      vw.debrisVelocities[i3] = vx;
      vw.debrisVelocities[i3 + 1] = vy;
      vw.debrisVelocities[i3 + 2] = vz;
    });

    for (let i = 0; i < toRelease.length; i++) {
      vw.releaseDebris(toRelease[i]);
    }
  }

  public stepPlayer(
    player: MinecraftPlayerState,
    keys: Record<string, boolean>,
    dt: number,
  ): void {
    const forwardX = -Math.sin(player.yaw);
    const forwardZ = -Math.cos(player.yaw);
    const rightX = Math.cos(player.yaw);
    const rightZ = -Math.sin(player.yaw);

    let moveX = 0;
    let moveZ = 0;
    if (keys.KeyW || keys.ArrowUp) {
      moveX += forwardX;
      moveZ += forwardZ;
    }
    if (keys.KeyS || keys.ArrowDown) {
      moveX -= forwardX;
      moveZ -= forwardZ;
    }
    if (keys.KeyD || keys.ArrowRight) {
      moveX += rightX;
      moveZ += rightZ;
    }
    if (keys.KeyA || keys.ArrowLeft) {
      moveX -= rightX;
      moveZ -= rightZ;
    }

    const moveLen = Math.hypot(moveX, moveZ);
    if (moveLen > 0.001) {
      moveX /= moveLen;
      moveZ /= moveLen;
    }

    const isSprint = Boolean(keys.ShiftLeft || keys.ShiftRight);
    const moveSpeed = player.flyMode ? (isSprint ? 18 : 11) : isSprint ? 8.8 : 5.6;

    const footBlock = this.getBlock(
      Math.floor(player.position.x),
      Math.floor(player.position.y - 1.4),
      Math.floor(player.position.z),
    );
    player.inWater = footBlock === MC_BLOCK.WATER;

    if (player.flyMode) {
      player.velocity.x = moveX * moveSpeed;
      player.velocity.z = moveZ * moveSpeed;
      let vy = 0;
      if (keys.Space) vy += moveSpeed * 0.85;
      if (keys.ControlLeft || keys.KeyC) vy -= moveSpeed * 0.85;
      player.velocity.y = vy;
      player.position.x += player.velocity.x * dt;
      player.position.y = Math.max(2, Math.min(MC_CHUNK_HEIGHT + 24, player.position.y + player.velocity.y * dt));
      player.position.z += player.velocity.z * dt;
      player.onGround = false;
      return;
    }

    player.velocity.x = moveX * moveSpeed;
    player.velocity.z = moveZ * moveSpeed;

    if (player.inWater) {
      player.velocity.y -= 8.0 * dt;
      if (keys.Space) player.velocity.y = 4.6;
      player.velocity.y *= Math.pow(0.25, dt);
    } else {
      player.velocity.y -= 24.0 * dt;
      if (keys.Space && player.onGround) {
        player.velocity.y = 8.8;
        player.onGround = false;
      }
    }

    const halfW = 0.28;
    const eyeH = 1.62;
    const headH = 0.18;

    const collides = (px: number, py: number, pz: number): boolean => {
      const minX = Math.floor(px - halfW);
      const maxX = Math.floor(px + halfW);
      const minY = Math.floor(py - eyeH);
      const maxY = Math.floor(py + headH);
      const minZ = Math.floor(pz - halfW);
      const maxZ = Math.floor(pz + halfW);
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          for (let x = minX; x <= maxX; x++) {
            if (this.isSolidCollider(x, y, z)) return true;
          }
        }
      }
      return false;
    };

    // Axis-separated AABB resolution
    const nx = player.position.x + player.velocity.x * dt;
    if (!collides(nx, player.position.y, player.position.z)) {
      player.position.x = nx;
    } else {
      player.velocity.x = 0;
    }

    const nz = player.position.z + player.velocity.z * dt;
    if (!collides(player.position.x, player.position.y, nz)) {
      player.position.z = nz;
    } else {
      player.velocity.z = 0;
    }

    const ny = player.position.y + player.velocity.y * dt;
    if (!collides(player.position.x, ny, player.position.z)) {
      player.position.y = ny;
      player.onGround = false;
    } else {
      if (player.velocity.y < 0) {
        player.onGround = true;
      }
      player.velocity.y = 0;
    }

    // Clamp to loaded world bounds
    const limit = (this.radiusChunks + 0.4) * MC_CHUNK_SIZE;
    player.position.x = Math.max(-limit, Math.min(limit, player.position.x));
    player.position.z = Math.max(-limit, Math.min(limit, player.position.z));
    if (player.position.y < 2) {
      player.position.copy(this.spawnPoint);
      player.velocity.set(0, 0, 0);
    }
  }

  public rebuildChunkGeometries(
    rec: MinecraftChunkRecord,
    options: { bakeAO: boolean; encodeColorInVertices: boolean; buildLod1: boolean },
  ): void {
    const getVoxel = (wx: number, wy: number, wz: number) => this.getBlock(wx, wy, wz);

    rec.opaqueGeo?.dispose();
    rec.lod1Geo?.dispose();
    rec.transGeo?.dispose();

    rec.opaqueGeo = Voxl.buildVoxelChunkGeometry({
      getVoxel,
      originX: rec.originX,
      originY: 0,
      originZ: rec.originZ,
      sizeX: MC_CHUNK_SIZE,
      sizeY: MC_CHUNK_HEIGHT,
      sizeZ: MC_CHUNK_SIZE,
      step: 1,
      lodLevel: 0,
      bakeAO: options.bakeAO,
      palette: MC_MESHER_PALETTE,
      transparentPass: false,
      encodeColorInVertices: options.encodeColorInVertices,
    });

    rec.lod1Geo = options.buildLod1
      ? Voxl.buildVoxelChunkGeometry({
          getVoxel,
          originX: rec.originX,
          originY: 0,
          originZ: rec.originZ,
          sizeX: MC_CHUNK_SIZE,
          sizeY: MC_CHUNK_HEIGHT,
          sizeZ: MC_CHUNK_SIZE,
          step: 2,
          lodLevel: 1,
          bakeAO: options.bakeAO,
          palette: MC_MESHER_PALETTE,
          transparentPass: false,
          encodeColorInVertices: options.encodeColorInVertices,
        })
      : null;

    rec.transGeo = Voxl.buildVoxelChunkGeometry({
      getVoxel,
      originX: rec.originX,
      originY: 0,
      originZ: rec.originZ,
      sizeX: MC_CHUNK_SIZE,
      sizeY: MC_CHUNK_HEIGHT,
      sizeZ: MC_CHUNK_SIZE,
      step: 1,
      lodLevel: 0,
      bakeAO: false,
      palette: MC_MESHER_PALETTE,
      transparentPass: true,
      encodeColorInVertices: true,
    });

    this.voxlWorld.chunkDirty[rec.slot] = 0;
  }

  public dispose(): void {
    for (const rec of this.chunks.values()) {
      rec.opaqueGeo?.dispose();
      rec.lod1Geo?.dispose();
      rec.transGeo?.dispose();
    }
    this.chunks.clear();
    this.voxlWorld.reset();
  }
}
