/**
 * Procedural CanvasTexture generator & Voxl EffectComposer ShaderPass definitions
 * for the VoxlCraft Minecraft Clone Showcase (zero dependencies outside `src/voxl`).
 */
import * as Voxl from '../../src';

/**
 * Creates a crisp 16x16 Minecraft-style pixelated bevel & grain CanvasTexture
 * that modulates vertex colors on MeshLambertMaterial / MeshBasicMaterial.
 */
export function createProceduralBlockTexture(): Voxl.CanvasTexture {
  const size = 16;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    let seed = 4242;
    const rand = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };

    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const isBorder = x === 0 || y === 0 || x === size - 1 || y === size - 1;
        const isHighlight = x === 1 || y === 1;
        const grain = (rand() - 0.5) * 28;
        const base = isBorder ? 212 : isHighlight ? 250 : 238;
        const v = Math.max(170, Math.min(255, Math.round(base + grain)));
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }

  const tex = new Voxl.CanvasTexture(canvas);
  tex.magFilter = Voxl.NearestFilter;
  tex.minFilter = Voxl.NearestFilter;
  tex.wrapS = Voxl.RepeatWrapping;
  tex.wrapT = Voxl.RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Voxl ShaderPass: Soft HDR Bloom highlight pass.
 */
export function createVoxlBloomShader(): Voxl.ShaderDefinition {
  return {
    uniforms: {
      tDiffuse: { value: null },
      uResolution: { value: new Voxl.Vector2(1280, 720) },
      uStrength: { value: 0.45 },
      uThreshold: { value: 0.62 },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D tDiffuse;
      uniform vec2 uResolution;
      uniform float uStrength;
      uniform float uThreshold;
      varying vec2 vUv;

      vec3 brightPass(vec3 c) {
        float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float soft = smoothstep(uThreshold - 0.12, uThreshold + 0.25, lum);
        return c * soft;
      }

      void main() {
        vec2 texel = 2.6 / max(uResolution, vec2(1.0));
        vec4 base = texture2D(tDiffuse, vUv);
        vec3 glow = vec3(0.0);
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(-texel.x, -texel.y)).rgb) * 0.11;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(0.0, -texel.y)).rgb) * 0.14;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(texel.x, -texel.y)).rgb) * 0.11;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(-texel.x, 0.0)).rgb) * 0.14;
        glow += brightPass(base.rgb) * 0.18;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(texel.x, 0.0)).rgb) * 0.14;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(-texel.x, texel.y)).rgb) * 0.11;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(0.0, texel.y)).rgb) * 0.14;
        glow += brightPass(texture2D(tDiffuse, vUv + vec2(texel.x, texel.y)).rgb) * 0.11;
        gl_FragColor = vec4(base.rgb + glow * uStrength, base.a);
      }
    `,
  };
}

/**
 * Voxl ShaderPass: Cinematic ACES contrast + subtle screen-space vignette.
 */
export function createVoxlVignetteShader(): Voxl.ShaderDefinition {
  return {
    uniforms: {
      tDiffuse: { value: null },
      uVignette: { value: 0.34 },
      uSaturation: { value: 1.12 },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D tDiffuse;
      uniform float uVignette;
      uniform float uSaturation;
      varying vec2 vUv;

      void main() {
        vec4 texel = texture2D(tDiffuse, vUv);
        vec3 col = texel.rgb;
        float luma = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(vec3(luma), col, uSaturation);
        // Subtle S-curve contrast
        col = clamp((col - 0.5) * 1.08 + 0.5, 0.0, 1.0);
        vec2 centered = vUv - 0.5;
        float vig = 1.0 - dot(centered, centered) * uVignette * 2.2;
        gl_FragColor = vec4(col * clamp(vig, 0.45, 1.0), texel.a);
      }
    `,
  };
}

/**
 * Voxl ShaderPass: Retro Pixel / Color-Quantized mode.
 */
export function createVoxlRetroPixelShader(): Voxl.ShaderDefinition {
  return {
    uniforms: {
      tDiffuse: { value: null },
      uResolution: { value: new Voxl.Vector2(1280, 720) },
      uPixelSize: { value: 4.0 },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D tDiffuse;
      uniform vec2 uResolution;
      uniform float uPixelSize;
      varying vec2 vUv;

      void main() {
        vec2 grid = max(uResolution / max(1.0, uPixelSize), vec2(1.0));
        vec2 snappedUv = (floor(vUv * grid) + 0.5) / grid;
        vec4 c = texture2D(tDiffuse, snappedUv);
        vec3 quant = floor(c.rgb * 14.0 + 0.5) / 14.0;
        gl_FragColor = vec4(quant, c.a);
      }
    `,
  };
}
