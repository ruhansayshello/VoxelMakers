import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import * as Voxl from '../../src';
import {
  MC_BLOCK,
  MC_MESHER_PALETTE,
  MinecraftWorldController,
} from './minecraftWorld';

describe('VoxlCraft Standalone Minecraft Example (100% src/voxl)', () => {
  it('generates procedural terrain, lake water, watchtower, torches, and TNT in Voxl.VoxelWorld SoA', () => {
    const world = new MinecraftWorldController(1, 1337);
    assert.equal(world.chunks.size, 9, '3x3 chunk grid for radius=1');
    assert.ok(world.torches.length >= 3, 'Watchtower should register torch point lights');
    assert.equal(world.getBlock(0, 0, 0), MC_BLOCK.STONE, 'Bedrock layer should be solid stone');

    // Verify TNT cluster placed at landmark showcase (-6, *, -8)
    let foundTnt = false;
    for (let y = 1; y < 30; y++) {
      if (world.getBlock(-6, y, -8) === MC_BLOCK.TNT) {
        foundTnt = true;
        break;
      }
    }
    assert.ok(foundTnt, 'TNT cluster should exist in landmark showcase');
    world.dispose();
  });

  it('meshes chunks via Voxl.buildVoxelChunkGeometry with LOD0, LOD1, baked AO, and transparent pass', () => {
    const world = new MinecraftWorldController(1, 1337);
    const centerChunk = world.chunks.get('0,0');
    assert.ok(centerChunk, 'Center chunk 0,0 should exist');

    world.rebuildChunkGeometries(centerChunk, {
      bakeAO: true,
      encodeColorInVertices: true,
      buildLod1: true,
    });

    assert.ok(centerChunk.opaqueGeo, 'Opaque LOD0 geometry should be created');
    assert.ok(centerChunk.lod1Geo, 'LOD1 geometry should be created');
    const lod0Verts = centerChunk.opaqueGeo.attributes.position.count;
    const lod1Verts = centerChunk.lod1Geo.attributes.position.count;
    assert.ok(lod0Verts > 0, 'LOD0 should emit vertices');
    assert.ok(lod1Verts > 0 && lod1Verts < lod0Verts, 'LOD1 should have fewer vertices than LOD0');
    assert.ok(centerChunk.opaqueGeo.attributes.uv, 'Mesher should emit UVs for CanvasTexture support');
    assert.ok(centerChunk.opaqueGeo.attributes.voxelMaterial, 'Mesher should emit voxelMaterial IDs');
    assert.ok(centerChunk.opaqueGeo.attributes.lodLevel, 'Mesher should emit lodLevel attribute');

    // Verify transparent glass/water pass works cleanly on watchtower chunk (0,-1)
    const towerChunk = world.chunks.get('0,-1');
    assert.ok(towerChunk, 'Watchtower chunk 0,-1 should exist');
    world.rebuildChunkGeometries(towerChunk, {
      bakeAO: true,
      encodeColorInVertices: true,
      buildLod1: false,
    });
    assert.ok(towerChunk.transGeo && towerChunk.transGeo.attributes.position.count > 0, 'Watchtower glass/water should emit transparent geometry');

    world.dispose();
  });

  it('supports DDA Voxl.raycastVoxels picking, block break/place, and TNT SoA debris physics', () => {
    const world = new MinecraftWorldController(1, 1337);
    const groundY = world.getHighestSolidY(2, 2);

    // Raycast straight down onto (2, groundY, 2)
    const hit = world.raycastBlock(
      new Voxl.Vector3(2.5, groundY + 4.5, 2.5),
      new Voxl.Vector3(0, -1, 0),
      10,
    );
    assert.ok(hit, 'Downward raycast should hit terrain block');
    assert.equal(hit.wx, 2);
    assert.equal(hit.wy, groundY);
    assert.equal(hit.wz, 2);
    assert.equal(hit.normalY, 1, 'Top face normal should be +Y');

    // Place a block on top
    world.setBlock(hit.wx + hit.normalX, hit.wy + hit.normalY, hit.wz + hit.normalZ, MC_BLOCK.METAL);
    assert.equal(world.getBlock(2, groundY + 1, 2), MC_BLOCK.METAL);

    // Break it and verify SoA debris spawns
    const broken = world.breakBlock(2, groundY + 1, 2, true);
    assert.equal(broken, 1);
    assert.equal(world.getBlock(2, groundY + 1, 2), MC_BLOCK.AIR);
    assert.ok(world.voxlWorld.activeDebrisCount >= 6, 'Breaking a block should spawn SoA debris');

    // Detonate TNT explosion and step debris physics
    const craterCount = world.detonateExplosion(2.5, groundY, 2.5, 3.0, true);
    assert.ok(craterCount > 10, 'Explosion should carve a multi-block crater');
    for (let i = 0; i < 15; i++) {
      world.stepDebrisPhysics(1 / 60);
    }
    assert.ok(world.voxlWorld.activeDebrisCount > 0, 'Active SoA debris should simulate cleanly');

    // Also verify standalone buildVoxelChunkGeometry AO off vs on
    const geoNoAo = Voxl.buildVoxelChunkGeometry({
      getVoxel: (x, y, z) => (x === 0 && y === 0 && z === 0 ? MC_BLOCK.STONE : MC_BLOCK.AIR),
      originX: 0,
      originY: 0,
      originZ: 0,
      sizeX: 2,
      sizeY: 2,
      sizeZ: 2,
      bakeAO: false,
      palette: MC_MESHER_PALETTE,
    });
    assert.equal(geoNoAo.attributes.position.count, 24, 'Single isolated voxel should have 6 faces * 4 verts = 24');
    geoNoAo.dispose();

    world.dispose();
  });
});
