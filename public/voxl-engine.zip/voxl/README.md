# Voxl — Standalone WebGL2 Voxel Engine

**Voxl** is a self-contained, zero-dependency WebGL2 TypeScript engine engineered specifically for voxel games, block sandboxes, destruction simulations, and procedural worlds. It provides a familiar Three.js-compatible scene graph and math API alongside purpose-built voxel systems: a Structure-of-Arrays (SoA) `VoxelWorld`, single-draw-call `ChunkBatchRenderer`, WebGL2 Transform Feedback `GPUChunkCuller`, stylized `VoxelPotatoShader` with GPU distance LOD, face-culled AO chunk mesher, 3D DDA voxel raycaster, and a hardware-blitted `EffectComposer` post-processing pipeline.

---

## Table of Contents

1. [Architecture & How Voxl Works](#1-architecture--how-voxl-works)
2. [Directory & Module Map](#2-directory--module-map)
3. [Installation & Project Setup](#3-installation--project-setup)
4. [Quickstart: Your First Voxel World](#4-quickstart-your-first-voxel-world)
5. [Core Systems — Detailed Usage Guide](#5-core-systems--detailed-usage-guide)
   - [5.1 VoxelWorld (SoA World, Chunks, Debris & Events)](#51-voxelworld-soa-world-chunks-debris--events)
   - [5.2 VoxelMesher & 3D DDA Raycasting](#52-voxelmesher--3d-dda-raycasting)
   - [5.3 ChunkBatchRenderer (Single-Draw-Call Batching)](#53-chunkbatchrenderer-single-draw-call-batching)
   - [5.4 GPUChunkCuller (WebGL2 Transform Feedback Culling)](#54-gpuchunkculler-webgl2-transform-feedback-culling)
   - [5.5 VoxelPotatoShader & GPU Distance LOD](#55-voxelpotatoshader--gpu-distance-lod)
   - [5.6 Standard Materials, Lights, Fog & Procedural Textures](#56-standard-materials-lights-fog--procedural-textures)
   - [5.7 EffectComposer Post-Processing Pipeline](#57-effectcomposer-post-processing-pipeline)
   - [5.8 InstancedMesh & LineSegments (Debris, Foliage & Cursors)](#58-instancedmesh--linesegments-debris-foliage--cursors)
   - [5.9 Math & Voxel-Specific Fast Paths](#59-math--voxel-specific-fast-paths)
   - [5.10 PerfProfiler Telemetry](#510-perfprofiler-telemetry)
6. [Common Pitfalls & Performance Best Practices](#6-common-pitfalls--performance-best-practices)
7. [Running the Unit Test Suite](#7-running-the-unit-test-suite)

---

## 1. Architecture & How Voxl Works

Voxl is built around a **zero-allocation-in-hot-path** philosophy tailored to voxel workloads where thousands of blocks, dozens of chunks, and hundreds of physical debris shards change every frame:

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           GAME / APPLICATION LAYER                         │
│  (World Gen · Player Controls · Physics · UI — imports ONLY from `voxl`)  │
└───────────────┬──────────────────────────────────────────┬─────────────────┘
                │                                          │
                ▼                                          ▼
┌───────────────────────────────┐        ┌───────────────────────────────────┐
│      VoxelWorld (SoA)         │        │     VoxelMesher + DDA Raycast     │
│  • TypedArray Chunk Tables    │───────▶│  • Face Culling + 4-Sample AO     │
│  • Dirty Flags & Damage Maps  │        │  • Diagonal Flip + UVs + LOD0/1/2 │
│  • Debris & RigidBody Pools   │        │  • Opaque / Transparent Passes    │
│  • Event Queues & Fixed Clock │        │  • Fast 3D DDA Block Picking      │
└───────────────┬───────────────┘        └─────────────────┬─────────────────┘
                │                                          │
                ▼                                          ▼
┌───────────────────────────────┐        ┌───────────────────────────────────┐
│   GPUChunkCuller (WebGL2 TF)  │───────▶│       ChunkBatchRenderer          │
│  • 6-Plane Frustum Test on GPU│        │  • Merges Visible Chunks into     │
│  • Automatic CPU Fallback     │        │    Pre-Allocated Dynamic Buffers  │
└───────────────────────────────┘        │  • Tight `bufferSubData` Ranges   │
                                         │  • Renders All Terrain in 1 Call  │
                                         └─────────────────┬─────────────────┘
                                                           │
                                                           ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                     WebGLRenderer (WebGL2 Backend)                         │
│  • WebGLState redundancy filter  • Cached VAOs & compiled shader programs  │
│  • InstancedMesh FIFO recycling  • Scale-Space multi-pass & RTE support    │
│  • VoxelPotatoShader (7-material palette, Fresnel rim, cel shade, GPU LOD) │
│  • Automatic EXT_color_buffer_float detection + RGBA8 FBO fallback         │
└────────────────────────────────────┬───────────────────────────────────────┘
                                     │ (optional)
                                     ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                    EffectComposer Post-Processing                          │
│  • Pre-allocated Ping-Pong WebGLRenderTargets (zero per-frame alloc)       │
│  • RenderPass → ShaderPass(es) (Bloom, Vignette, Retro, etc.) → OutputPass │
│  • Hardware `gl.blitFramebuffer` presentation & disabled-pass skipping     │
└────────────────────────────────────────────────────────────────────────────┘
```

### Key Internal Mechanisms
1. **Structure-of-Arrays (SoA) Storage (`VoxelWorld`)**: Instead of allocating millions of JS objects per voxel or debris cube, `VoxelWorld` stores chunk voxel bytes (`Uint8Array`), damage maps, world origins (`Int32Array`), dirty flags (`Uint8Array`), and debris/body transforms (`Float32Array`) in flat pre-allocated typed arrays. This keeps garbage collection pauses near zero.
2. **State & Binding Caching (`WebGLState`, `WebGLBindingStates`, `WebGLPrograms`)**: Before issuing any WebGL2 state change (`useProgram`, `enable(DEPTH_TEST)`, `blendFunc`, `bindTexture`, `viewport`), the renderer checks its mirror state and skips redundant driver calls. Geometry attribute layouts are cached inside WebGL2 VAOs.
3. **Single-Draw-Call Merging (`ChunkBatchRenderer`)**: Visible chunks are copied into pre-allocated dynamic typed arrays (`position`, `normal`, `uv`, `color`, `voxelMaterial`, `lodLevel`, `index`) only when a chunk becomes dirty or the visible chunk set changes, uploading only the active slice via `addUpdateRange` + `gl.bufferSubData`.
4. **Hardware Frustum Culling (`GPUChunkCuller`)**: Uploads all chunk bounding spheres (`vec4(x, y, z, radius)`) once per frame into a WebGL2 Transform Feedback vertex shader (`gl.RASTERIZER_DISCARD`) that tests all spheres against the 6 frustum planes in parallel. Automatically falls back to `Frustum.cullChunkArray` on CPU if Transform Feedback readback is unavailable.
5. **Safe FBO Attachments (`WebGLTextures`)**: Automatically requests `EXT_color_buffer_float` and `EXT_color_buffer_half_float` at startup; if a GPU or software renderer (e.g., SwiftShader) does not support float color attachments, render targets automatically downgrade to `RGBA8` (`UNSIGNED_BYTE`) so `EffectComposer` framebuffers are always complete and renderable.

---

## 2. Directory & Module Map

Everything is re-exported cleanly from `src/voxl/index.ts`:

| Directory | Purpose & Main Exports |
| :--- | :--- |
| `src/voxl/index.ts` | Single public barrel entry point (`import * as Voxl from './voxl'`) |
| `src/voxl/constants.ts` | WebGL2 / rendering constants (`DoubleSide`, `NearestFilter`, `ACESFilmicToneMapping`, etc.) |
| `src/voxl/math/` | `Vector2`, `Vector3` (with `packToInt32`/`unpackFromInt32`), `Vector4`, `Matrix3`, `Matrix4` (with `makeVoxelTransform`), `Quaternion`, `Euler`, `Color`, `Box3`, `Sphere`, `Plane`, `Ray`, `Frustum` (with `cullChunkArray`), `MathUtils` |
| `src/voxl/core/` | `Object3D`, `Group`, `Mesh`, `BufferGeometry`, `BufferAttribute`, `InstancedBufferAttribute`, `Clock`, `EventDispatcher` |
| `src/voxl/cameras/` | `Camera`, `PerspectiveCamera`, `OrthographicCamera` |
| `src/voxl/lights/` | `AmbientLight`, `HemisphereLight`, `DirectionalLight`, `PointLight`, `SpotLight`, `LightShadow` |
| `src/voxl/geometries/` | `BoxGeometry`, `PlaneGeometry`, `SphereGeometry`, `CylinderGeometry`, `ConeGeometry`, `RingGeometry`, `TorusGeometry`, `OctahedronGeometry`, `DodecahedronGeometry`, `EdgesGeometry` |
| `src/voxl/materials/` | `Material`, `MeshBasicMaterial`, `MeshLambertMaterial`, `MeshStandardMaterial`, `MeshPhysicalMaterial`, `MeshPhongMaterial`, `ShaderMaterial`, `LineBasicMaterial`, `PointsMaterial`, `SpriteMaterial` |
| `src/voxl/objects/` | `InstancedMesh` (with `setMaxCount`/`recycleInstance`), `Line`, `LineSegments`, `LineLoop`, `Points`, `Sprite`, `GridHelper`, `Raycaster` |
| `src/voxl/scenes/` | `Scene`, `Fog`, `FogExp2` |
| `src/voxl/textures/` | `Texture`, `CanvasTexture`, `DataTexture`, `DepthTexture` |
| `src/voxl/renderers/` | `WebGLRenderer`, `WebGLRenderTarget`, and internal WebGL2 pipeline (`webgl/*`) |
| `src/voxl/postprocessing/` | `EffectComposer`, `RenderPass`, `ShaderPass`, `OutputPass`, `CopyShader`, `FullScreenQuad`, `Pass` |
| `src/voxl/voxel/` | `buildVoxelChunkGeometry`, `raycastVoxels`, `ChunkBatchRenderer`, `GPUChunkCuller`, `VoxelPotatoShader` (`createVoxelPotatoMaterial`, `setVoxelMaterialPaletteEntry`) |
| `src/voxl/world/` | `VoxelWorld`, `encodeChunkId`, `getActiveVoxelWorld`, `setActiveVoxelWorld` |
| `src/voxl/perf/` | `PerfProfiler`, `perfProfiler` |
| `src/voxl/compat/` | Loader compatibility helpers |

---

## 3. Installation & Project Setup

Voxl has **zero runtime npm dependencies** — it runs directly on standard TypeScript + WebGL2 in any modern browser and bundler (Vite, esbuild, Webpack, Bun).

### Option A: Copy Directly Into Your Project (Recommended)
1. Unzip `voxl-engine.zip` and copy `voxl/src/` into your project (e.g., `src/voxl/`).
2. Import directly from your local folder:
   ```ts
   import * as Voxl from './voxl';
   ```

### Option B: Add a Path Alias in Vite & TypeScript
In `vite.config.ts`:
```ts
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  resolve: {
    alias: {
      voxl: path.resolve(__dirname, 'src/voxl/index.ts'),
      // Optional: drop-in Three.js alias if porting existing Three.js code
      // three: path.resolve(__dirname, 'src/voxl/index.ts'),
    },
  },
});
```

In `tsconfig.json`:
```json
{
  "compilerOptions": {
    "paths": {
      "voxl": ["./src/voxl/index.ts"]
    }
  }
}
```

Then import cleanly anywhere:
```ts
import * as Voxl from 'voxl';
```

---

## 4. Quickstart: Your First Voxel World

Here is a complete, minimal 60-line program that initializes a WebGL2 canvas, populates a `VoxelWorld` chunk, meshes it with baked Ambient Occlusion, and renders it with `VoxelPotatoShader`:

```ts
import * as Voxl from './voxl';

// 1. Renderer, Scene & Camera
const renderer = new Voxl.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
document.body.appendChild(renderer.domElement);

const scene = new Voxl.Scene();
scene.background = new Voxl.Color(0x7cc4f5);

const camera = new Voxl.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 200);
camera.position.set(14, 12, 18);
camera.lookAt(8, 4, 8);

// 2. Create a VoxelWorld SoA container & populate one 16x16x16 chunk
const world = new Voxl.VoxelWorld({
  maxChunks: 16,
  chunkX: 16,
  chunkY: 16,
  chunkZ: 16,
});

const chunkId = Voxl.encodeChunkId(0, 0);
world.acquireChunkSlot(chunkId, 0, 0, 0);

const BLOCK_GRASS = 1;
const BLOCK_STONE = 2;

for (let z = 0; z < 16; z++) {
  for (let x = 0; x < 16; x++) {
    const h = 3 + Math.floor(Math.sin(x * 0.4) * 2 + Math.cos(z * 0.4) * 2);
    for (let y = 0; y <= h; y++) {
      world.setVoxel(x, y, z, y === h ? BLOCK_GRASS : BLOCK_STONE);
    }
  }
}

// 3. Mesh the chunk with face culling & baked 4-sample vertex AO
const palette: Record<number, Voxl.VoxelMesherPaletteEntry> = {
  [BLOCK_GRASS]: { color: 0x7c5c3e, topColor: 0x52a83e, shaderMatId: Voxl.VOXEL_MAT_GRASS },
  [BLOCK_STONE]: { color: 0x838b94, shaderMatId: Voxl.VOXEL_MAT_STONE },
};

const geometry = Voxl.buildVoxelChunkGeometry({
  getVoxel: (wx, wy, wz) => world.getVoxel(wx, wy, wz),
  originX: 0,
  originY: 0,
  originZ: 0,
  sizeX: 16,
  sizeY: 16,
  sizeZ: 16,
  bakeAO: true,
  palette,
  encodeColorInVertices: true,
});

// 4. Stylized VoxelPotatoShader (white palette colors so vertex colors drive albedo)
const whitePalette = Voxl.createDefaultVoxelMaterialPalette().map((e) => ({
  ...e,
  color: new Voxl.Color(0xffffff),
  aoContribution: 1.0,
}));
const material = Voxl.createVoxelPotatoMaterial({ palette: whitePalette });

const chunkMesh = new Voxl.Mesh(geometry, material);
scene.add(chunkMesh);

// 5. Render Loop
function frame() {
  requestAnimationFrame(frame);
  renderer.render(scene, camera);
}
frame();
```

---

## 5. Core Systems — Detailed Usage Guide

### 5.1 `VoxelWorld` (SoA World, Chunks, Debris & Events)

`VoxelWorld` manages four flat Structure-of-Arrays tables: **Chunks**, **Rigid Bodies**, **Falling Debris**, and **Event Queues**.

```ts
const world = new Voxl.VoxelWorld({
  maxChunks: 64,   // Maximum resident chunks
  maxBodies: 32,   // Maximum dynamic rigid bodies
  maxDebris: 450,  // Ring-buffered debris pool capacity
  chunkX: 16,      // Chunk X dimension in voxels
  chunkY: 32,      // Chunk Y dimension in voxels
  chunkZ: 16,      // Chunk Z dimension in voxels
  fixedDt: 1 / 60, // Fixed physics timestep
});
```

#### Chunk Management & Voxel Access
```ts
// Acquire a chunk slot at world origin (cx * 16, 0, cz * 16)
const chunkId = Voxl.encodeChunkId(cx, cz);
const slot = world.acquireChunkSlot(chunkId, cx * 16, 0, cz * 16, {
  allocateDamage: true, // Optional per-voxel uint8 health buffer
});

// Read / write voxels in world coordinates (automatically marks chunkDirty[slot] = 1)
world.setVoxel(wx, wy, wz, 3);
const matId = world.getVoxel(wx, wy, wz);

// Apply voxel damage (decrements health, destroys voxel & pushes VoxelDestroyedEvent at 0)
world.damageVoxel(wx, wy, wz, 100, 'explosion');

// Check & clear dirty chunks when remeshing
if (world.chunkDirty[slot] !== 0) {
  // ... rebuild chunk geometry ...
  world.chunkDirty[slot] = 0;
}

// Release chunk when out of view
world.releaseChunkSlot(slot);
```

#### Boundary Remeshing Tip
When modifying a voxel on the edge of a chunk (`lx === 0 || lx === chunkX - 1 || lz === 0 || lz === chunkZ - 1`), also mark the neighboring chunk slot dirty so shared faces update cleanly:
```ts
const nSlot = world.getChunkSlotById(Voxl.encodeChunkId(cx + 1, cz));
if (nSlot >= 0) world.markChunkDirty(nSlot);
```

#### Debris Pool (Zero-Allocation Ring Buffer)
```ts
// Spawn a falling voxel shard (recycles resting debris first, then oldest active)
world.spawnDebris(
  x, y, z,          // Initial world position
  vx, vy, vz,       // Initial velocity
  0xd93829,         // Hex color
  0.25,             // Cube size
  6.0,              // Lifetime in seconds
);

// Iterate all active debris without heap allocations
const toRelease: number[] = [];
world.forEachAllDebris((slot) => {
  world.debrisLifetimes[slot] -= dt;
  if (world.debrisLifetimes[slot] <= 0) {
    toRelease.push(slot);
    return;
  }
  const i3 = slot * 3;
  world.debrisVelocities[i3 + 1] -= 22.0 * dt;
  world.debrisPositions[i3]     += world.debrisVelocities[i3] * dt;
  world.debrisPositions[i3 + 1] += world.debrisVelocities[i3 + 1] * dt;
  world.debrisPositions[i3 + 2] += world.debrisVelocities[i3 + 2] * dt;
});
for (const slot of toRelease) world.releaseDebris(slot);
```

---

### 5.2 `VoxelMesher` & 3D DDA Raycasting

`buildVoxelChunkGeometry` generates an indexed `BufferGeometry` in **local chunk space** (`0..sizeX`, `0..sizeY`, `0..sizeZ`) with:
- Automatic hidden-face culling against neighboring solid voxels (calling your `getVoxel` across chunk boundaries seamlessly).
- Separate **opaque** (`transparentPass: false`) and **transparent** (`transparentPass: true`, e.g., water & glass) passes.
- **4-sample per-vertex Baked Ambient Occlusion** (`bakeAO: true`) with automatic quad-diagonal flipping to eliminate AO interpolation artifacts.
- **Multi-resolution LOD generation** via `step` (`1` = LOD0, `2` = LOD1, `4` = LOD2) and `lodLevel` attribute stamping.
- Emitted vertex attributes: `position`, `normal`, `uv`, `color`, `voxelMaterial` (`Int8Array`), `lodLevel` (`Int8Array`), and `index`.

```ts
const opaqueLod0 = Voxl.buildVoxelChunkGeometry({
  getVoxel: (wx, wy, wz) => world.getVoxel(wx, wy, wz),
  originX: cx * 16,
  originY: 0,
  originZ: cz * 16,
  sizeX: 16,
  sizeY: 32,
  sizeZ: 16,
  step: 1,
  lodLevel: 0,
  bakeAO: true,
  palette,
  transparentPass: false,
  encodeColorInVertices: true,
});
```

> **Important:** Because `buildVoxelChunkGeometry` outputs vertices in **local chunk coordinates** (`0..size`), always set `mesh.position.set(originX, originY, originZ)` (for individual meshes) or `batchEntry.position = { x: originX, y: originY, z: originZ }` (for `ChunkBatchRenderer`).

#### Fast 3D DDA Block Picking (`raycastVoxels`)
```ts
const hit: Voxl.VoxelDDARaycastHit | null = Voxl.raycastVoxels(
  camera.position,
  lookDirection,
  8.0, // max reach in voxels
  (wx, wy, wz) => world.getVoxel(wx, wy, wz),
  (matId) => matId !== 0 && matId !== WATER_ID, // predicate for pickable voxels
);

if (hit) {
  // Break hit block:
  // world.setVoxel(hit.wx, hit.wy, hit.wz, 0);

  // Place new block on the clicked face:
  const placeX = hit.wx + hit.normalX;
  const placeY = hit.wy + hit.normalY;
  const placeZ = hit.wz + hit.normalZ;
}
```

---

### 5.3 `ChunkBatchRenderer` (Single-Draw-Call Batching)

Rendering 50–200 individual chunk meshes triggers 50–200 WebGL draw calls per frame. `ChunkBatchRenderer` merges all visible chunks into **one pre-allocated `BufferGeometry`** and draws the entire visible terrain in **1 draw call**.

```ts
const chunkBatcher = new Voxl.ChunkBatchRenderer({
  maxVertexCount: 320_000,
  maxIndexCount: 520_000,
  material: myOpaqueMaterial,
  enableGpuLod: true,
});

// Recommended pattern: add chunkBatcher.mesh to the Scene so it works seamlessly
// with BOTH direct `renderer.render(scene, camera)` AND `EffectComposer` RenderPass!
scene.add(chunkBatcher.mesh);
```

Each chunk entry implements `BatchableChunk`:
```ts
const entry: Voxl.BatchableChunk = {
  id: `${cx},${cz}:0`,
  geometry: opaqueLod0,
  position: { x: originX, y: 0, z: originZ },
  boundingSphere: worldSphere, // World-space bounding sphere
  lodLevel: 0,
};
```

Every frame:
```ts
// Call update() WITHOUT passing `renderer` so it merges buffers only when dirty
// or when visibility changes, then Scene / RenderPass draws chunkBatcher.mesh in 1 call!
chunkBatcher.update(visibleBatchEntries, camera);
```

Whenever a chunk is remeshed, call `chunkBatcher.markDirty()`.

---

### 5.4 `GPUChunkCuller` (WebGL2 Transform Feedback Culling)

Tests hundreds of chunk bounding spheres against the camera's 6 frustum planes in parallel on the GPU via WebGL2 Transform Feedback, with an automatic CPU fallback (`Frustum.intersectsSphere`) if Transform Feedback readback is unsupported.

```ts
const gl = renderer.getContext();
const gpuCuller = new Voxl.GPUChunkCuller(gl, 256);

console.log('Transform Feedback active:', gpuCuller.isGPUActive);

// Each frame (after camera.updateMatrixWorld(true)):
const visibility: Float32Array = gpuCuller.cullSpheres(chunkWorldSpheres, camera);
for (let i = 0; i < chunks.length; i++) {
  const isVisible = visibility[i] > 0.5;
  // include in batcher or toggle mesh.visible = isVisible
}
```

---

### 5.5 `VoxelPotatoShader` & GPU Distance LOD

`createVoxelPotatoMaterial` creates a fast stylized voxel `ShaderMaterial` featuring:
- A 7-slot material uniform palette (`uMatColors[7]`, `uMatProps[7]` storing `hardness`, `aoContribution`, `rimBoost`, `alpha`).
- Hemisphere ambient lighting + 3-band cel shading (no expensive `pow`/`sin` calls).
- Cubic Fresnel rim highlights scaled per material (`VOXEL_MAT_METAL` gleams sharply; `VOXEL_MAT_DIRT` stays matte).
- Integrated linear distance fog (`uFogEnabled`, `uFogColor`, `uFogNear`, `uFogFar`).
- **Single-draw-call GPU LOD (`uEnableGpuLod`)**: Pass both LOD0 (`lodLevel: 0`) and LOD1 (`lodLevel: 1`) geometries into `ChunkBatchRenderer`; the vertex shader discards vertices whose `lodLevel` doesn't match the camera distance band `uLodDistances` (`x` = LOD0→LOD1 distance, `y` = LOD1→LOD2 distance)!

#### Vertex-Color vs Palette-Color Modes
`VoxelPotatoShader` computes `baseAlbedo = uMatColors[matId] * mix(vec3(1.0), vColor, aoContrib)`:
- **Per-block rich colors (Minecraft style)**: Set every `uMatColors[i]` to `0xffffff` (while keeping distinct `hardness`/`rimBoost` per material ID) and mesh with `encodeColorInVertices: true`. This also lets you hot-swap between `VoxelPotatoShader`, `MeshLambertMaterial`, and `MeshBasicMaterial` with zero remeshing!
- **Palette-driven colors**: Use `createDefaultVoxelMaterialPalette()` (or customize via `setVoxelMaterialPaletteEntry(...)`) and mesh with `encodeColorInVertices: false` so `vColor` carries pure grayscale AO.

```ts
// Updating sun direction & fog dynamically each frame
(potatoMat.uniforms.uLightDir.value as Voxl.Vector3).set(sunX, sunY, sunZ).normalize();
potatoMat.uniforms.uFogEnabled.value = 1.0;
(potatoMat.uniforms.uFogColor.value as Voxl.Color).setHex(0x7cc4f5);
potatoMat.uniforms.uEnableGpuLod.value = 1.0;
potatoMat.uniformsNeedUpdate = true;
```

---

### 5.6 Standard Materials, Lights, Fog & Procedural Textures

Voxl includes familiar Three.js-compatible materials, lights, fog, and textures:

- **Materials**: `MeshBasicMaterial`, `MeshLambertMaterial`, `MeshStandardMaterial`, `MeshPhysicalMaterial`, `MeshPhongMaterial`, `ShaderMaterial`, `LineBasicMaterial`, `PointsMaterial`, `SpriteMaterial`.
- **Lights**: `AmbientLight`, `HemisphereLight`, `DirectionalLight`, `PointLight`, `SpotLight`.
- **Fog**: `scene.fog = new Voxl.Fog(0x7cc4f5, 22, 86)` or `new Voxl.FogExp2(0x7cc4f5, 0.019)`.
- **Procedural `CanvasTexture`** (crisp pixel-art voxel grain):

```ts
const canvas = document.createElement('canvas');
canvas.width = 16;
canvas.height = 16;
const ctx = canvas.getContext('2d')!;
// ... draw 16x16 texture ...

const tex = new Voxl.CanvasTexture(canvas);
tex.magFilter = Voxl.NearestFilter;
tex.minFilter = Voxl.NearestFilter;
tex.wrapS = Voxl.RepeatWrapping;
tex.wrapT = Voxl.RepeatWrapping;
tex.needsUpdate = true;

const mat = new Voxl.MeshLambertMaterial({ vertexColors: true, map: tex });
```

---

### 5.7 `EffectComposer` Post-Processing Pipeline

`EffectComposer` allocates ping-pong `WebGLRenderTarget` buffers **once at startup**, skips disabled passes completely, and presents to the screen via hardware `gl.blitFramebuffer` when possible.

```ts
// Recommended color-space config when rendering sRGB-encoded vertex colors + ACES tone mapping:
renderer.outputColorSpace = Voxl.LinearSRGBColorSpace;
renderer.toneMapping = Voxl.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.85;

const composer = new Voxl.EffectComposer(renderer);
const renderPass = new Voxl.RenderPass(scene, camera);
const bloomPass = new Voxl.ShaderPass(myBloomShaderDef);
const outputPass = new Voxl.OutputPass();

composer.addPass(renderPass);
composer.addPass(bloomPass);
composer.addPass(outputPass);

// Toggle passes at runtime with zero allocations:
bloomPass.enabled = true;

// On window resize:
composer.setSize(width, height);

// In render loop:
composer.render(dt);
```

---

### 5.8 `InstancedMesh` & `LineSegments` (Debris, Foliage & Cursors)

#### Instanced Rendering (1 Draw Call for Hundreds of Objects)
```ts
const debrisGeo = new Voxl.BoxGeometry(1, 1, 1);
const debrisMat = new Voxl.MeshLambertMaterial({ color: 0xffffff });
const debrisMesh = new Voxl.InstancedMesh(debrisGeo, debrisMat, 450);
debrisMesh.frustumCulled = false;
scene.add(debrisMesh);

// Update per-instance transform & color (reuse scratch Matrix4/Color objects!)
debrisMesh.setMatrixAt(i, scratchMatrix);
debrisMesh.setColorAt(i, scratchColor);
debrisMesh.count = activeCount;
debrisMesh.instanceMatrix.needsUpdate = true;
if (debrisMesh.instanceColor) debrisMesh.instanceColor.needsUpdate = true;
```

`InstancedMesh` also provides voxel-specific pool helpers: `setMaxCount(n)` (pre-allocates buffers once) and `recycleInstance()` (O(1) FIFO ring-buffer slot index).

#### Wireframe Block Selection Cursor (`EdgesGeometry` + `LineSegments`)
```ts
const edges = new Voxl.EdgesGeometry(new Voxl.BoxGeometry(1.02, 1.02, 1.02));
const cursor = new Voxl.LineSegments(edges, new Voxl.LineBasicMaterial({ color: 0x0f172a }));
scene.add(cursor);

// Position on raycast hit:
cursor.position.set(hit.wx + 0.5, hit.wy + 0.5, hit.wz + 0.5);
```

---

### 5.9 Math & Voxel-Specific Fast Paths

In addition to full Three.js-compatible `Vector2/3/4`, `Matrix3/4`, `Quaternion`, `Euler`, `Color`, `Box3`, `Sphere`, `Plane`, `Ray`, `Frustum`, and `MathUtils`, Voxl includes voxel-specific hot-path helpers:

- **`Vector3.packToInt32(x, y, z)` / `Vector3.unpackFromInt32(packed, target)`**: Packs integer voxel coordinates into a single 32-bit integer for compact map keys or typed-array queues.
- **`Matrix4.makeVoxelTransform(x, y, z, scale)`**: Fast-path translation + uniform scale into a `Float32Array(16)` without full quaternion compose overhead.
- **`Frustum.cullChunkArray(chunks)`**: Bulk frustum culling across chunk bounding spheres returning visible indices.

---

### 5.10 `PerfProfiler` Telemetry

Track rolling 60-frame FPS, frame time, draw calls, triangle counts, and SoA pool stats with zero per-frame allocations:

```ts
const profiler = new Voxl.PerfProfiler();

// Inside animation loop:
profiler.beginFrame();
renderer.info.reset();
renderer.render(scene, camera);

profiler.recordRenderPassStats(renderer.info.render.calls, renderer.info.render.triangles, true);
profiler.endFrame({
  frameDeltaMs: dt * 1000,
  physicsTotalMs: 0,
  physicsSteps: 1,
  renderMs,
  worldUpdateMs: 0,
  debrisUpdateMs: 0,
  activeBodies: 0,
  totalBodies: 0,
  activeDebris: world.activeDebrisCount,
  visibleChunks,
  dirtyChunks,
});

// Read throttled snapshot (e.g. every 200ms) for UI HUD:
const snap = profiler.getSnapshot();
console.log(snap.fps, snap.drawCalls, snap.triangles);
```

---

## 6. Common Pitfalls & Performance Best Practices

1. **Always call `dispose()` on unmount/remesh**: Dispose replaced `BufferGeometry`, `Material`, `Texture`, `ChunkBatchRenderer`, `GPUChunkCuller`, `EffectComposer`, and `WebGLRenderer` to free GPU buffers, VAOs, textures, and FBOs cleanly.
2. **Never allocate math objects inside `requestAnimationFrame`**: Hoist scratch `Vector3`, `Matrix4`, `Quaternion`, `Euler`, and `Color` instances outside your render loop.
3. **Chunk coordinates are local**: `buildVoxelChunkGeometry` emits local `(0..size)` positions; remember to supply `position: { x: originX, y: originY, z: originZ }` on `BatchableChunk` and `mesh.position.set(originX, originY, originZ)` on standalone chunk meshes.
4. **Combine `ChunkBatchRenderer` + `EffectComposer` cleanly**: Add `chunkBatcher.mesh` to your `Scene` and call `chunkBatcher.update(visibleEntries, camera)` *without* passing `renderer`. That way `RenderPass` renders the single merged mesh inside the post-processing FBO automatically.
5. **Clamp pixel ratio on software WebGL renderers**: Detect `SwiftShader` / `llvmpipe` via `gl.getParameter(gl.RENDERER)` and cap `renderer.setPixelRatio(1)` to keep headless/software sessions responsive.
6. **Throttle React/DOM HUD updates**: Poll `profiler.getSnapshot()` at ~5 Hz instead of every frame so DOM reconciliation never steals frame budget.
7. **Complete reference implementation**: See `examples/minecraft/` (VoxlCraft) for a complete, playable Minecraft-style application exercising every single subsystem above with live feature toggles.

---

## 7. Running the Unit Test Suite

Voxl ships with standalone Node `node:test` unit tests covering the renderer, post-processing, chunk batching, GPU culler, `VoxelPotatoShader`, `VoxelWorld` SoA, and the Minecraft reference example (zero runtime or test dependencies):

```bash
npx tsx --test \
  src/voxl/voxel/voxel.test.ts \
  src/voxl/world/VoxelWorld.test.ts \
  src/voxl/renderers/renderer.test.ts \
  src/voxl/postprocessing/postprocessing.test.ts
```

Optional Three.js parity tests (`src/voxl/constants.test.ts` and `src/voxl/math/math.test.ts`) compare Voxl's math and constant values against `three` when `three` is installed as a devDependency.
